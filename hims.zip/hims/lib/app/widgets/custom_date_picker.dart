import 'package:flutter/material.dart';
import 'package:hims_flutter/app/constants/colors.dart';
import 'package:hims_flutter/app/constants/styles.dart';
import 'package:intl/intl.dart';

class CustomDatePicker extends StatefulWidget {


  final String title;
  final TextEditingController date;
  CustomDatePicker({super.key,required this.title, required this.date});

  @override
  State<CustomDatePicker> createState() => _CustomDatePickerState();
}

class _CustomDatePickerState extends State<CustomDatePicker> {

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 50,
      child: TextField(
        controller: widget.date,
        //editing controller of this TextField
        decoration: InputDecoration(
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: AppColors.primary),
            borderRadius: BorderRadius.circular(12.0),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: AppColors.grey),
            borderRadius: BorderRadius.circular(12.0),
          ),
          hintText: widget.title,
          hintStyle: smallStyle.copyWith(color: AppColors.grey),
          prefixIcon: Icon(Icons.calendar_today),
          prefixIconColor: AppColors.grey,
        ),
        readOnly: true,
        //set it true, so that user will not able to edit text
        onTap: () async {
          DateTime? pickedDate = await showDatePicker(
              context: context,
              initialDate: DateTime.now(),
              firstDate: DateTime(1950),
              //DateTime.now() - not to allow to choose before today.
              lastDate: DateTime(2100));

          if (pickedDate != null) {
            print(
                pickedDate); //pickedDate output format => 2021-03-10 00:00:00.000
            String formattedDate = DateFormat('yyyy-MM-dd').format(pickedDate);
            print(
                formattedDate); //formatted date output using intl package =>  2021-03-16
            setState(() {
              widget.date.text = formattedDate; //set output date to TextField value.
            });
          } else {}
        },
      ),
    );
  }
}

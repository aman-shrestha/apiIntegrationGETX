import 'package:flutter/material.dart';

import '../constants/colors.dart';
import '../constants/styles.dart';
class SearchField extends StatelessWidget {
  final String text;
  const SearchField({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 50,
      child: TextField(
        decoration: InputDecoration(
          focusedBorder:OutlineInputBorder(
            borderSide: BorderSide(color: AppColors.primary),
            borderRadius: BorderRadius.circular(12.0),
          ) ,
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: AppColors.grey),
            borderRadius: BorderRadius.circular(12.0),
          ),
          hintText: text,
          filled: true,
          fillColor: Colors.grey.shade300,
          hintStyle: smallStyle.copyWith(color: AppColors.grey),
          // prefixIcon: prefixIcon: icon,
          prefixIcon: Icon(Icons.search),
          prefixIconColor: AppColors.grey,

        ),
      ),
    );  }
}

import 'package:flutter/material.dart';
import 'package:hims_flutter/app/constants/colors.dart';
import 'package:hims_flutter/app/constants/styles.dart';
class CheckboxView extends StatelessWidget {
  final String title;
  final bool clicked;
  const CheckboxView({super.key, required this.title, required this.clicked});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(clicked?Icons.check_box:Icons.check_box_outline_blank_outlined,color: AppColors.primary,),
        SizedBox(width: 8.0,),
        Text(title,style: smallStyle)
      ],
    );
  }
}

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hims_flutter/app/constants/styles.dart';
import 'package:hims_flutter/app/modules/profile/views/profile_view.dart';

import '../constants/colors.dart';

class ProfileBar extends StatelessWidget {
  final String title;
  const ProfileBar({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 60, 16, 16),
      decoration: const BoxDecoration(
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(22.0), // Set the bottom-left radius
          bottomRight: Radius.circular(22.0), // Set the bottom-right radius
        ),
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[
            Color.fromRGBO(65, 116, 212, 1),
            Color.fromRGBO(163, 92, 219, 1),
          ],
        ),
      ),
      child:
      Row(
        children: [
          GestureDetector(
            onTap: () {
              Get.to(() => ProfileView());
            },
            child: Image.asset("assets/images/pp.png"),
          ),
          SizedBox(width: 10),
          Text(
            title,
            style: normalStyle.copyWith(
                color: Colors.white, fontWeight: FontWeight.bold),
          ),
          Spacer(),
          Icon(Icons.mail_outline_outlined, color: AppColors.white,size: 28),
          SizedBox(width: 10),
          Icon(Icons.notifications_none_rounded, color: AppColors.white,size: 28),
        ],
      ),
    );
  }
}
  
// }

import 'package:flutter/material.dart';
import 'package:hims_flutter/app/constants/colors.dart';

import '../constants/styles.dart';

class CustomDropdown extends StatelessWidget {
  final Icon dropdownIcon;
  final List<String> items;
  final ValueNotifier<String> stateValue;
  final Function(String) onValueChanged; // Callback function

  CustomDropdown(
      {
      required this.dropdownIcon,
      required this.items,
      required this.stateValue,
      required this.onValueChanged});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      alignment: Alignment.center,
      padding: EdgeInsets.only(left: 12.0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(12.0),
      ),
      child: Row(
        children: [
          dropdownIcon,
          SizedBox(width: 4.0),
          Expanded(
            child: DropdownButton(
              padding: EdgeInsets.symmetric(horizontal: 4.0),
              elevation: 1,
              isExpanded: true,
              value: stateValue.value,
              underline: Container(),
              icon: const Icon(Icons.keyboard_arrow_down),
              items: items.map((String item) {
                return DropdownMenuItem(
                  value: item,
                  child: Text(
                    item,
                    style: TextStyle(fontSize: 16.0),
                  ),
                );
              }).toList(),
              onChanged: (String? newValue) {
                stateValue.value = newValue!;
                onValueChanged(newValue!); // Invoke the callback
              },
            ),
          ),
        ],
      ),
    );
  }
}

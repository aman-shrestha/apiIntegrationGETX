import 'package:flutter/material.dart';
import 'package:hims_flutter/app/constants/colors.dart';
import 'package:hims_flutter/app/constants/styles.dart';

class CustomTextField extends StatelessWidget {
  final String hint;
  final Icon icon;
  final TextEditingController textEditingController;
  const CustomTextField({Key? key, required this.hint, required this.icon, required this.textEditingController})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      child: TextField(
        controller: textEditingController,
        decoration: InputDecoration(
          focusedBorder:OutlineInputBorder(
            borderSide: BorderSide(color: AppColors.primary),
            borderRadius: BorderRadius.circular(12.0),
          ) ,
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: AppColors.grey),
            borderRadius: BorderRadius.circular(12.0),
          ),
          hintText: hint,
          hintStyle: smallStyle.copyWith(color: AppColors.grey),
          prefixIcon: icon,
          prefixIconColor: AppColors.grey,

        ),
        // obscureText: isObsecure,
      ),
    );
    ;
  }
}

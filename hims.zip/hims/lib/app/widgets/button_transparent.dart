import 'package:flutter/material.dart';
import 'package:hims_flutter/app/constants/colors.dart';

import '../constants/styles.dart';
class TransparentButton extends StatelessWidget {
  final String title;
  const TransparentButton({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 48,
      width: 110,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12.0),
        border: Border.all(color: AppColors.primary),
      ),
      child: Center(
        child: Text(
          title,
          style: miniStyle.copyWith(
              fontWeight: FontWeight.w500, color: AppColors.primary),
        ),
      ),
    );
  }
}

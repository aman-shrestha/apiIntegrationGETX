import 'package:intl/intl.dart';

class TimeUtils{

  String formatDate(String inputDate) {
    // Parse the input string into a DateTime object
    DateTime parsedDate = DateTime.parse(inputDate);

    // Create a formatter for the desired output format
    DateFormat outputFormat = DateFormat('yyyy-MM-dd');

    // Format the date using the formatter
    String formattedDate = outputFormat.format(parsedDate);

    return formattedDate;
  }


  String calculateTimeDifference(String inputDate) {
    // Parse the input string into a DateTime object
    DateTime inputDateTime = DateTime.parse(inputDate);

    // Get the current time
    DateTime now = DateTime.now();
    // Calculate the time difference
    Duration difference = now.difference(inputDateTime);
    // Calculate days, hours, minutes, and seconds
    int days = difference.inDays;
    int hours = difference.inHours.remainder(24);
    int minutes = difference.inMinutes.remainder(60);
    int seconds = difference.inSeconds.remainder(60);

    // Build the result string
    if (days > 0) {
      return '$days day${days == 1 ? "" : "s"} ago';
    } else if (hours > 0) {
      return '$hours hour${hours == 1 ? "" : "s"} ago';
    } else if (minutes > 0) {
      return '$minutes minute${minutes == 1 ? "" : "s"} ago';
    } else {
      return 'just now';
    }
  }}
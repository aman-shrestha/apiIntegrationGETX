import 'dart:convert';
import 'dart:io';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:hims_flutter/app/constants/colors.dart';
import 'package:http/http.dart' as http;


class ApiClient {
  final localData = GetStorage();

  // var responseData = ResponseModel().obs;
  // var refreshTokenData = RefreshTokenModel().obs;
  // final localData = GetStorage();

  //get method
  Future<http.Response> getRequest(String url) async {
    try {
      var response = await http.get(
        Uri.parse(url),
        headers: {
          HttpHeaders.authorizationHeader:
              'Bearer ' + localData.read('access_token'),
        },
      );
      print("Response::::::::${response.body}");
      if (response.statusCode == 403) {
        // refreshToken();
        // Get.offAll(() => LoginView());
        Get.rawSnackbar(
          message: 'Token Expired Please Login Again',
          backgroundColor: AppColors.grey.shade600,
          duration: Duration(seconds: 1),
          snackPosition: SnackPosition.BOTTOM,
        );
      } else if (response.statusCode != 200) {
        Get.rawSnackbar(
            message: "Error",
            backgroundColor: AppColors.grey.shade800,
            duration: Duration(seconds: 2),
            animationDuration: Duration(milliseconds: 100),
            snackPosition: SnackPosition.BOTTOM);
      }
      return response;
    } catch (error, stackTrace) {
      print('An error occurred: $error');
      print('Stack trace: $stackTrace');
      throw error; // Rethrow the error to propagate it to the caller
    }
  }

  //post method
  Future<http.Response> postRequest(
      String url, Map<String, dynamic> body) async {
    try {
      var response = await http.post(Uri.parse(url),
          headers: {
            HttpHeaders.authorizationHeader:
                'Bearer ' + localData.read('access_token'),
          },
          body: body);
      print("Response::::::::${response.body}");
      if (response.statusCode == 403) {
        // refreshToken();
        // Get.offAll(() => LoginView());
        Get.rawSnackbar(
          message: 'Token Expired Please Login Again',
          backgroundColor: AppColors.grey.shade600,
          duration: Duration(seconds: 1),
          snackPosition: SnackPosition.BOTTOM,
        );
      } else if (response.statusCode > 201) {
        // showErrorMessage(response);
        Get.rawSnackbar(
            message: "Error",
            backgroundColor: AppColors.grey.shade800,
            duration: Duration(seconds: 2),
            animationDuration: Duration(milliseconds: 100),
            snackPosition: SnackPosition.BOTTOM);
      }
      return response;
    } catch (error) {
      print('An error occurred: $error');
      throw error; // Rethrow the error to propagate it to the caller
    }
  }

  //post request without token

  Future<http.Response> postRequestWithoutToken(
      String url, Map<String, dynamic> body) async {
    try {
      var jsonData = body; // Convert the data to a JSON string
      var response = await http.post(Uri.parse(url),
          body: jsonData); // Use the JSON string as the request body
      print("Response:${response.body}");
      if (response.statusCode > 201) {
        // showErrorMessage(response);
        Get.rawSnackbar(
            message: "Error",
            backgroundColor: AppColors.grey.shade800,
            duration: Duration(seconds: 2),
            animationDuration: Duration(milliseconds: 100),
            snackPosition: SnackPosition.BOTTOM);
      }
      return response;
    } catch (error) {
      print('An error occurred: $error');
      throw error; // Rethrow the error to propagate it to the caller
    }
  }

  Future<http.Response> createAccount(
      String url, Map<String, dynamic> body) async {
    try {
      var jsonData = json.encode(body); // Convert the data to a JSON string
      var response = await http.post(Uri.parse(url),
          headers: {
            // 'x-api-key': Constants.API_KEY,
            HttpHeaders.contentTypeHeader: "application/json",
            HttpHeaders.acceptHeader: "application/json",
            HttpHeaders.contentEncodingHeader: "charset=UTF-8",
          },
          body: jsonData); // Use the JSON string as the request body
      print("Response:${response.body}");
      if (response.statusCode > 201) {
        Get.rawSnackbar(
            message:
                "Either username or email is already taken or phone number is not valid",
            backgroundColor: AppColors.grey.shade800,
            duration: Duration(seconds: 2),
            animationDuration: Duration(milliseconds: 100),
            snackPosition: SnackPosition.BOTTOM);
      }
      return response;
    } catch (error) {
      print('An error occurred: $error');
      throw error; // Rethrow the error to propagate it to the caller
    }
  }

  //patch method
  // Future<http.Response> patchRequest(
  //     String url, Map<String, dynamic> body) async {
  //   try {
  //     var response = await http.patch(Uri.parse(url),
  //         headers: {
  //           'x-api-key': Constants.API_KEY,
  //           "content-type": "application/json",
  //           HttpHeaders.authorizationHeader:
  //               'Bearer ' + localData.read('access_token'),
  //         },
  //         body: jsonEncode(body));
  //     print("res:" + response.body);
  //
  //     if (response.statusCode == 401) {
  //       // refreshToken();
  //       Get.offAll(() => LoginView());
  //       Get.rawSnackbar(
  //         message: 'Token Expired Please Login Again',
  //         backgroundColor: AppColors.grey.shade600,
  //         duration: Duration(seconds: 1),
  //         snackPosition: SnackPosition.BOTTOM,
  //       );
  //     } else if (response.statusCode > 201) {
  //       // showErrorMessage(response);
  //       Get.rawSnackbar(
  //           message: "Error",
  //           backgroundColor: AppColors.grey.shade800,
  //           duration: Duration(seconds: 2),
  //           animationDuration: Duration(milliseconds: 100),
  //           snackPosition: SnackPosition.BOTTOM);
  //     }
  //     return response;
  //   } catch (error) {
  //     print('An error occurred: $error');
  //     throw error; // Rethrow the error to propagate it to the caller
  //   }
  // }

  //method for refreshing token
  // Future<void> refreshToken() async {
  //   var json_body = {
  //     "access": localData.read('access_token'),
  //     "refresh": localData.read('refresh_token')
  //   };
  //   var response =
  //       await http.post(Uri.parse(Constants.BASE_URL + Constants.REFRESH_TOKEN),
  //           headers: {
  //             'x-api-key': Constants.API_KEY,
  //           },
  //           body: json_body);
  //   if (response.statusCode == 200) {
  //     RefreshTokenModel refreshTokenModel =
  //         RefreshTokenModel.fromJson(jsonDecode(response.body));
  //     refreshTokenData.value = refreshTokenModel;
  //     localData.write("access_token", refreshTokenData.value.access);
  //     localData.write("refresh_token", refreshTokenData.value.refresh);
  //   } else {
  //     Get.offAll(LoginView(), transition: Transition.fade);
  //     Get.rawSnackbar(
  //         message: 'Token Expired,Please Login Again',
  //         backgroundColor: AppColors.grey.shade800,
  //         duration: Duration(seconds: 2),
  //         animationDuration: Duration(milliseconds: 100),
  //         snackPosition: SnackPosition.BOTTOM);
  //   }
  // }

  // showErrorMessage(var response) {
  //   print("came here");
  //   ResponseModel responseModel =
  //       ResponseModel.fromJson(jsonDecode(response.body));
  //   responseData.value = ResponseModel(
  //     detail: responseModel.detail,
  //   );
  //   Get.rawSnackbar(
  //       message: responseData.value.detail.toString(),
  //       backgroundColor: AppColors.grey.shade800,
  //       duration: Duration(seconds: 2),
  //       animationDuration: Duration(milliseconds: 100),
  //       snackPosition: SnackPosition.BOTTOM);
  // }
}

mixin ApiUrls {
  static const String BASE_URL = "https://himsapi.nepalehr.com/api/v1";
  // static const String BASE_URL ="http://192.168.1.105:8000/api/v1";
  static const String LOGIN = "/accounts/login/";
  static const String SIGNUP="/accounts/register/";
  static const String USER_PROFILE_INFO="/mobile_user/profile-info/";
  static const String USER_EDUCATION_INFO="/mobile_user/education/";
  static const String USER_EXPERIENCE_INFO="/mobile_user/work-experience/";
  static const String HOSPITALS_LIST="/hospital/hospital-dropdown/all/";
  static const String LIBRARY_LIST="/library/book-management/";
  static const String GET_BOOK="/get_book/";
  static const String NOTICE_LIST="/communication/notice/";
  static const String JOBS_LIST="/vacancy/jobs-management/";
  static const String APPLY_VACANCY="/vacancy/applicant-management/";
  static const String GET_VITALS="/mobile_user/vital/";
}

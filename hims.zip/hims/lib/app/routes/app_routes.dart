part of 'app_pages.dart';
// DO NOT EDIT. This is code generated via package:get_cli/get_cli.dart

abstract class Routes {
  Routes._();
  static const HOME = _Paths.HOME;
  static const SIGNUP = _Paths.SIGNUP;
  static const LOGIN = _Paths.LOGIN;
  static const OTP_VERIFY = _Paths.OTP_VERIFY;
  static const USER_DETAIL_FORM = _Paths.USER_DETAIL_FORM;
  static const BOTTOM_NAV = _Paths.BOTTOM_NAV;
  static const DASHBOARD = _Paths.DASHBOARD;
  static const NOTICE = _Paths.NOTICE;
  static const LIBRARY = _Paths.LIBRARY;
  static const JOBS = _Paths.JOBS;
  static const QR = _Paths.QR;
  static const NOTICE_DETAILS = _Paths.NOTICE_DETAILS;
  static const DOCUMENTS_DETAILS = _Paths.DOCUMENTS_DETAILS;
  static const PROFILE = _Paths.PROFILE;
  static const SPLASH = _Paths.SPLASH;
  static const APPLY_VACANCY = _Paths.APPLY_VACANCY;
}

abstract class _Paths {
  _Paths._();
  static const HOME = '/home';
  static const SIGNUP = '/signup';
  static const LOGIN = '/login';
  static const OTP_VERIFY = '/otp-verify';
  static const USER_DETAIL_FORM = '/user-detail-form';
  static const BOTTOM_NAV = '/bottom-nav';
  static const DASHBOARD = '/dashboard';
  static const NOTICE = '/notice';
  static const LIBRARY = '/library';
  static const JOBS = '/jobs';
  static const QR = '/qr';
  static const NOTICE_DETAILS = '/notice-details';
  static const DOCUMENTS_DETAILS = '/documents-details';
  static const PROFILE = '/profile';
  static const SPLASH = '/splash';
  static const APPLY_VACANCY = '/apply-vacancy';
}

import 'package:get/get.dart';
import '../modules/applyVacancy/bindings/apply_vacancy_binding.dart';
import '../modules/applyVacancy/views/apply_vacancy_view.dart';
import '../modules/bottomNav/bindings/bottom_nav_binding.dart';
import '../modules/bottomNav/views/bottom_nav_view.dart';
import '../modules/dashboard/bindings/dashboard_binding.dart';
import '../modules/dashboard/views/dashboard_view.dart';
import '../modules/documentsDetails/bindings/documents_details_binding.dart';
import '../modules/documentsDetails/views/documents_details_view.dart';
import '../modules/home/bindings/home_binding.dart';
import '../modules/home/views/home_view.dart';

import '../modules/jobs/bindings/jobs_binding.dart';
import '../modules/jobs/views/jobs_view.dart';
import '../modules/library/bindings/library_binding.dart';
import '../modules/library/views/library_view.dart';
import '../modules/login/bindings/login_binding.dart';
import '../modules/login/views/login_view.dart';
import '../modules/notice/bindings/notice_binding.dart';
import '../modules/notice/views/notice_view.dart';
import '../modules/noticeDetails/bindings/notice_details_binding.dart';
import '../modules/noticeDetails/views/notice_details_view.dart';
import '../modules/otpVerify/bindings/otp_verify_binding.dart';
import '../modules/otpVerify/views/otp_verify_view.dart';
import '../modules/profile/bindings/profile_binding.dart';
import '../modules/profile/views/profile_view.dart';
import '../modules/qr/bindings/qr_binding.dart';
import '../modules/qr/views/qr_view.dart';
import '../modules/signup/bindings/signup_binding.dart';
import '../modules/signup/views/signup_view.dart';
import '../modules/splash/bindings/splash_binding.dart';
import '../modules/splash/views/splash_view.dart';
import '../modules/userDetailForm/bindings/user_detail_form_binding.dart';
import '../modules/userDetailForm/views/user_detail_form_view.dart';

part 'app_routes.dart';

class AppPages {
  AppPages._();

  static const INITIAL = Routes.SPLASH;

  static final routes = [
    GetPage(
      name: _Paths.HOME,
      page: () => HomeView(),
      binding: HomeBinding(),
    ),
    GetPage(
      name: _Paths.SIGNUP,
      page: () => SignupView(),
      binding: SignupBinding(),
    ),
    GetPage(
      name: _Paths.LOGIN,
      page: () => LoginView(),
      binding: LoginBinding(),
    ),
    GetPage(
      name: _Paths.OTP_VERIFY,
      page: () => const OtpVerifyView(),
      binding: OtpVerifyBinding(),
    ),
    GetPage(
      name: _Paths.USER_DETAIL_FORM,
      page: () => UserDetailFormView(),
      binding: UserDetailFormBinding(),
    ),
    GetPage(
      name: _Paths.BOTTOM_NAV,
      page: () => BottomNavView(),
      binding: BottomNavBinding(),
    ),
    GetPage(
      name: _Paths.DASHBOARD,
      page: () => DashboardView(),
      binding: DashboardBinding(),
    ),
    GetPage(
      name: _Paths.NOTICE,
      page: () => NoticeView(),
      binding: NoticeBinding(),
    ),
    GetPage(
      name: _Paths.LIBRARY,
      page: () => LibraryView(),
      binding: LibraryBinding(),
    ),
    GetPage(
      name: _Paths.JOBS,
      page: () => JobsView(),
      binding: JobsBinding(),
    ),
    GetPage(
      name: _Paths.QR,
      page: () => const QrView(),
      binding: QrBinding(),
    ),
    GetPage(
      name: _Paths.NOTICE_DETAILS,
      page: () => NoticeDetailsView(),
      binding: NoticeDetailsBinding(),
    ),
    GetPage(
      name: _Paths.DOCUMENTS_DETAILS,
      page: () => DocumentsDetailsView(),
      binding: DocumentsDetailsBinding(),
    ),
    GetPage(
      name: _Paths.PROFILE,
      page: () => ProfileView(),
      binding: ProfileBinding(),
    ),
    GetPage(
      name: _Paths.SPLASH,
      page: () => SplashView(),
      binding: SplashBinding(),
    ),
    GetPage(
      name: _Paths.APPLY_VACANCY,
      page: () => ApplyVacancyView(),
      binding: ApplyVacancyBinding(),
    ),
  ];
}

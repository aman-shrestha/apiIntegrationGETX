import 'package:get/get.dart';

import '../controllers/user_detail_form_controller.dart';

class UserDetailFormBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<UserDetailFormController>(
      () => UserDetailFormController(),
    );
  }
}

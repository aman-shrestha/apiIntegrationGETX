import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hims_flutter/app/constants/colors.dart';
import 'package:hims_flutter/app/modules/userDetailForm/controllers/user_detail_form_controller.dart';
import 'package:hims_flutter/app/widgets/button_large.dart';
import 'package:hims_flutter/app/widgets/custom_date_picker.dart';
import 'package:hims_flutter/app/widgets/custom_dropdown.dart';

import '../../../constants/styles.dart';
import '../../../widgets/custom_textfield.dart';

class ProfileInfoView extends StatefulWidget {



  ProfileInfoView({super.key});

  @override
  State<ProfileInfoView> createState() => _ProfileInfoViewState();
}

class _ProfileInfoViewState extends State<ProfileInfoView> {
  final controller = Get.put(UserDetailFormController());

  final fn = TextEditingController();

  final ln = TextEditingController();

  final date = TextEditingController();

  final contact = TextEditingController();

  final address = TextEditingController();

  List<String> gender = ["Male", "Female", "Undefined"];
  String getGender="";

  ValueNotifier<String> genderValue = ValueNotifier<String>('Male');

  @override
  void handleDropdownValueChanged(String newValue) {
    setState(() {
      getGender=newValue;
    });
  }

    Widget build(BuildContext context) {
      return Column(
        children: [
          Text(
            "Profile info",
            style: largeStyle.copyWith(fontWeight: FontWeight.w700),
          ),
          const SizedBox(
            height: 10,
          ),
          Text(
            "Fill in the data for profile. It will take a couple of minutes.",
            style: miniStyle,
          ),
          const SizedBox(
            height: 18,
          ),
          CustomTextField(
            hint: "First Name",
            icon: Icon(Icons.person), textEditingController: fn,
          ),
          const SizedBox(
            height: 16,
          ),
          CustomTextField(hint: "Last Name",
            icon: Icon(Icons.person),
            textEditingController: ln,),
          const SizedBox(
            height: 16,
          ),
          CustomDatePicker(title:"DOB",date: date),
          const SizedBox(
            height: 16,
          ),
          CustomDropdown(
            dropdownIcon: Icon(Icons.male,color: AppColors.grey),
              items: gender,
              stateValue: genderValue,
              onValueChanged: handleDropdownValueChanged),
          const SizedBox(
            height: 16,
          ),
          CustomTextField(hint: "Contact Number",
            icon: Icon(Icons.phone),
            textEditingController: contact,),
          const SizedBox(
            height: 16,
          ),
          CustomTextField(
            hint: "Address",
            icon: Icon(Icons.location_history_outlined),
            textEditingController: address,),
          const SizedBox(
            height: 70,
          ),
          GestureDetector(
              onTap: () {
                controller.postProfileInfo(fn.text, ln.text,contact.text, date.text,address.text);
                // controller.pageCounter.value++;
              },
              child: LargeButton(title: "Next")),
          const SizedBox(
            height: 20,
          ),
          Obx(()=>controller.isUploadingProfile.value?CircularProgressIndicator(color: AppColors.primary):Container()),


        ],
      );
    }
}

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hims_flutter/app/constants/colors.dart';
import 'package:hims_flutter/app/modules/userDetailForm/controllers/user_detail_form_controller.dart';
import 'package:hims_flutter/app/widgets/button_large.dart';
import 'package:hims_flutter/app/widgets/custom_date_picker.dart';

import '../../../constants/styles.dart';
import '../../../widgets/custom_textfield.dart';
class EducationInfoView extends StatelessWidget {

  final controller=Get.put(UserDetailFormController());


  final school=TextEditingController();
  final degree=TextEditingController();
  final field=TextEditingController();
  final address=TextEditingController();
  final percentage=TextEditingController();
  final startDate=TextEditingController();
  final endDate=TextEditingController();




  EducationInfoView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      child: SingleChildScrollView(
        child: Column(
          children: [
            Text(
              "Education info",
              style: largeStyle.copyWith(fontWeight: FontWeight.w700),
            ),
            const SizedBox(
              height: 10,
            ),
            Text(
              "Fill in the data for profile. It will take a couple of minutes.",
              style: miniStyle,
            ),
            const SizedBox(
              height: 18,
            ),
            CustomTextField(hint: "School/University", icon: Icon(Icons.house), textEditingController: school,),
            const SizedBox(
              height: 16,
            ),
            CustomTextField(hint: "Education Level", icon: Icon(Icons.school), textEditingController: degree,),
            const SizedBox(
              height: 16,
            ),
            CustomTextField(
                hint: "Field of Study", icon: Icon(Icons.menu_book), textEditingController: field,),
            const SizedBox(
              height: 16,
            ),
            CustomDatePicker(title:"Start Date",date: startDate),
            const SizedBox(
              height: 16,
            ),
            CustomDatePicker(title:"End Date",date: endDate),
            const SizedBox(
              height: 16,
            ),
            // const CustomTextField(
            //   hint: "Start Date",
            //   icon: Icon(Icons.calendar_month),
            // ),
            // const SizedBox(
            //   height: 16,
            // ),
            // const CustomTextField(hint: "End Date", icon: Icon(Icons.calendar_month)),
            // const SizedBox(
            //   height: 16,
            // ),
            CustomTextField(hint: "Percentage", icon: Icon(Icons.percent), textEditingController: percentage,),
            const SizedBox(
              height: 70,
            ),
            GestureDetector(
                onTap: (){
                  controller.postEducationInfo(field.text,startDate.text,endDate.text, school.text, degree.text, percentage.text);
                  // controller.pageCounter.value++;
                },
                child: LargeButton(title: "Next")),
            const SizedBox(
              height: 20,
            ),
            Obx(()=>controller.isUploadingEducation.value?CircularProgressIndicator(color: AppColors.primary):Container()),


          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import 'package:get/get.dart';
import 'package:hims_flutter/app/constants/images.dart';
import 'package:hims_flutter/app/modules/userDetailForm/views/education_info_view.dart';
import 'package:hims_flutter/app/modules/userDetailForm/views/experience_info_view.dart';
import 'package:hims_flutter/app/modules/userDetailForm/views/profile_info_view.dart';
import 'package:hims_flutter/app/widgets/button_small.dart';
import 'package:hims_flutter/app/widgets/button_transparent.dart';

import '../controllers/user_detail_form_controller.dart';

class UserDetailFormView extends GetView<UserDetailFormController> {
  UserDetailFormView({Key? key}) : super(key: key);

  @override
  final controller=Get.put(UserDetailFormController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: Container(
        padding: EdgeInsets.all(16.0),
        height: double.infinity,
        width: double.infinity,
        child: SingleChildScrollView(
          child: Obx(
            () => Column(
              children: [
                SizedBox(height: 60.0),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SvgPicture.asset(controller.pageCounter.value == 0
                        ? AppIcons.personFilled
                        : AppIcons.personOutlined),
                    SizedBox(width: 4.0),
                    SvgPicture.asset(AppIcons.dashedLine),
                    SizedBox(width: 4.0),
                    SvgPicture.asset(controller.pageCounter.value == 1
                        ? AppIcons.personFilled
                        : AppIcons.personOutlined),
                    SizedBox(width: 4.0),
                    SvgPicture.asset(AppIcons.dashedLine),
                    SizedBox(width: 4.0),
                    SvgPicture.asset(controller.pageCounter.value == 2
                        ? AppIcons.experienceFilled
                        : AppIcons.experienceOutlined),
                  ],
                ),
                SizedBox(height: 30.0),
                changeView(),
                SizedBox(height: 50.0),

              ],
            ),
          ),
        ),
      ),
    );
  }

  changeView() {
    if (controller.pageCounter.value == 0) {
      return ProfileInfoView();
    } else if (controller.pageCounter.value == 1) {
      return EducationInfoView();
    } else {
      return ExperienceInfoView();
    }
  }
}

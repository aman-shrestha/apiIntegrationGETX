import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hims_flutter/app/constants/colors.dart';
import 'package:hims_flutter/app/modules/bottomNav/views/bottom_nav_view.dart';
import 'package:hims_flutter/app/modules/dashboard/views/dashboard_view.dart';
import 'package:hims_flutter/app/modules/userDetailForm/controllers/user_detail_form_controller.dart';
import 'package:hims_flutter/app/widgets/button_large.dart';
import 'package:hims_flutter/app/widgets/checkbox_view.dart';
import 'package:hims_flutter/app/widgets/custom_date_picker.dart';
import 'package:hims_flutter/app/widgets/custom_dropdown.dart';

import '../../../constants/styles.dart';
import '../../../widgets/custom_textfield.dart';
class ExperienceInfoView extends StatefulWidget {

  ExperienceInfoView({super.key});

  @override
  State<ExperienceInfoView> createState() => _ExperienceInfoViewState();
}

class _ExperienceInfoViewState extends State<ExperienceInfoView> {
  final controller=Get.put(UserDetailFormController());

  final title=TextEditingController();

  final employment=TextEditingController();

  final company=TextEditingController();

  final location=TextEditingController();

  var currentlyWorking=false.obs;


  List<String> employmentType = [ "Full-Time", "Part-Time", "Contract", "Temporary", "Travel Nurse", "Internship", "Volunteer", "Other" ];

  String getEmploymentType="";

  ValueNotifier<String> employmentTypeValue = ValueNotifier<String>("Full-Time");

  List<String> locationType = ["Sector", "Location 1", "Location 2"];

  String getLocationType="";

  ValueNotifier<String> locationTypeValue = ValueNotifier<String>('Sector');


  final sd=TextEditingController();
  final ed=TextEditingController();




  void handleEmpTypeDropdownValueChanged(String newValue) {
    setState(() {
      getEmploymentType=newValue;
    });
  }

  void handleLocationTypeDropdownValueChanged(String newValue) {
    setState(() {
      getLocationType=newValue;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      child: SingleChildScrollView(
        child: Column(
          children: [
            Text(
              "Experience info",
              style: largeStyle.copyWith(fontWeight: FontWeight.w700),
            ),
            const SizedBox(
              height: 10,
            ),
            Text(
              "Fill in the data for profile. It will take a couple of minutes.",
              style: miniStyle,
            ),
            const SizedBox(
              height: 18,
            ),
            CustomTextField(hint: "Title of Role", icon: Icon(Icons.person), textEditingController: title,),
            const SizedBox(
              height: 16,
            ),
            CustomDropdown(
              dropdownIcon: Icon(Icons.person,color: AppColors.grey),
                items: employmentType,
                stateValue: employmentTypeValue,
                onValueChanged: handleEmpTypeDropdownValueChanged),
            const SizedBox(
              height: 16,
            ),
            CustomTextField(
                hint: "Company Name", icon: Icon(Icons.location_city), textEditingController: company,),
            const SizedBox(
              height: 16,
            ),
            CustomTextField(
              hint: "Location",
              icon: Icon(Icons.location_on), textEditingController: location,
            ),
            const SizedBox(
              height: 16,
            ),
            CustomDropdown(
                dropdownIcon: Icon(Icons.location_on,color: AppColors.grey),
                items: locationType,
                stateValue: locationTypeValue,
                onValueChanged: handleLocationTypeDropdownValueChanged),
            const SizedBox(
              height: 16,
            ),
            Obx(()=>
             GestureDetector(
                  onTap: (){
                    currentlyWorking.value=!currentlyWorking.value;
                  },
                  child: CheckboxView(title: "I am currently working in this role", clicked: currentlyWorking.value)),
            ),
            const SizedBox(
              height: 16,
            ),
            CustomDatePicker(title:"Start Date",date: sd),
            const SizedBox(
              height: 16,
            ),
            CustomDatePicker(title:"End Date",date: ed),
            const SizedBox(
              height: 70,
            ),
            GestureDetector(
                onTap: (){
                  controller.postExperienceInfo(getEmploymentType, title.text, location.text, currentlyWorking.value,sd.text,ed.text);
                  // Get.offAll(()=>BottomNavView());
                },
                child: LargeButton(title: "Submit")),
            const SizedBox(
              height: 20,
            ),
            Obx(()=>controller.isUploadingExperience.value?CircularProgressIndicator(color: AppColors.primary):Container()),

            // CustomTextField(
            //     hint: "Start Date", icon: Icon(Icons.calendar_month), textEditingController: null,),
            // const SizedBox(
            //   height: 16,
            // ),
            // CustomTextField(hint: "End Date", icon: Icon(Icons.calendar_month), textEditingController: null,),


          ],
        ),
      ),
    );  }
}

import 'package:get/get.dart';
import 'package:hims_flutter/app/constants/colors.dart';
import 'package:hims_flutter/app/data/remote/api_client.dart';
import 'package:hims_flutter/app/data/remote/api_urls.dart';
import 'package:hims_flutter/app/modules/bottomNav/views/bottom_nav_view.dart';
import 'package:hims_flutter/app/modules/dashboard/views/dashboard_view.dart';
import 'package:http/http.dart' as http;


class UserDetailFormController extends GetxController {
  //TODO: Implement UserDetailFormController

  final count = 0.obs;
  var pageCounter = 0.obs;
  var isUploadingProfile=false.obs;
  var isUploadingEducation=false.obs;
  var isUploadingExperience=false.obs;





  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }






  Future<void> postProfileInfo(String fn, String ln,String pn,String dob,String address) async {

    isUploadingProfile.value=true;
    Map<String, dynamic> requestBody = {
      "insurance_number": "string",
      "location": address,
      "experience": "2147483647",
      "birth_date": dob,
      "nationality": "string",
      "country": "string",
      "marital_status": "Single"
    };
    Future<http.Response> response = ApiClient().postRequest(
        ApiUrls.BASE_URL + ApiUrls.USER_PROFILE_INFO, requestBody);
    response.then((http.Response response) {
      if (response.statusCode == 200 || response.statusCode == 201) {
        pageCounter.value++;
        isUploadingProfile.value=false;
        print("profile info updated");
      } else {
        isUploadingProfile.value=false;
      }
    });
  }


  Future<void> postEducationInfo(String field,String sd, String ed, String institute,String education,String percentage) async {
    isUploadingEducation.value=true;

    // isSigningIn.value = true;
    Map<String, dynamic> requestBody = {
      "field_of_study": field,
      "start_date": sd,
      "end_date": ed,
      "institute_name": institute,
      "level_of_education": education,
      "percentage": percentage
    };
    Future<http.Response> response = ApiClient().postRequest(
        ApiUrls.BASE_URL + ApiUrls.USER_EDUCATION_INFO, requestBody);
    response.then((http.Response response) {
      if (response.statusCode == 200 || response.statusCode == 201) {
        pageCounter.value++;
        isUploadingEducation.value=false;

        print("education info updated");
      } else {
        isUploadingEducation.value=true;

      }
    });
  }


  Future<void> postExperienceInfo(String empType, String position,String location,bool currentlyWorking,String sd,String ed) async {
   isUploadingExperience.value=true;
    Map<String, dynamic> requestBody = {
      "employment_type": empType,
      "position": position,
      "location": location,
      "start_date": sd,
      "end_date": ed,
      "currently_working": currentlyWorking.toString()
    };
    Future<http.Response> response = ApiClient().postRequest(
        ApiUrls.BASE_URL + ApiUrls.USER_EXPERIENCE_INFO, requestBody);
    response.then((http.Response response) {
      if (response.statusCode == 200 || response.statusCode == 201) {
        Get.offAll(()=>BottomNavView());
        isUploadingExperience.value=false;
        Get.rawSnackbar(
            message:
            "User Details uploaded successfully",
            backgroundColor: AppColors.grey.shade800,
            duration: Duration(seconds: 2),
            animationDuration: Duration(milliseconds: 100),
            snackPosition: SnackPosition.BOTTOM);

        print("experience info updated");
      } else {
        isUploadingExperience.value=false;


      }
    });
  }



}

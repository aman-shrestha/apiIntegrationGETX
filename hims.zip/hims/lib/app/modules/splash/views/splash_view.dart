import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:hims_flutter/app/constants/colors.dart';
import 'package:hims_flutter/app/constants/styles.dart';

import '../controllers/splash_controller.dart';

class SplashView extends GetView<SplashController> {
  @override
  final controller=Get.put(SplashController());

  SplashView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: AppColors.white,
        child: Center(
          child: Text(
            'HIMS',
            style: largeStyle,
          ),
        ),
      ),
    );
  }
}

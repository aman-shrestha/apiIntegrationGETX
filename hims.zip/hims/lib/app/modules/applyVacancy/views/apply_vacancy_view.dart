import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';

import 'package:get/get.dart';
import 'package:hims_flutter/app/constants/colors.dart';
import 'package:hims_flutter/app/constants/dimens.dart';
import 'package:hims_flutter/app/constants/styles.dart';
import 'package:hims_flutter/app/widgets/button_small.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

import '../controllers/apply_vacancy_controller.dart';

class ApplyVacancyView extends GetView<ApplyVacancyController> {
  String title = Get.arguments[0];
  String deadline = Get.arguments[1];
  String description = Get.arguments[2];
  int id=Get.arguments[3];


  @override
  final controller=Get.put(ApplyVacancyController());

  ApplyVacancyView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Apply Vacancy",
          style: TextStyle(color: AppColors.primary),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: false,
        foregroundColor: AppColors.primary,
      ),
      body: Container(
        color: AppColors.white,
        height: double.infinity,
        width: double.infinity,
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Material(
                elevation: 2,
                borderRadius: BorderRadius.circular(16),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: normalStyle.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(
                        height: 8,
                      ),
                      Text("Deadline (" + deadline + ")"),
                      const SizedBox(
                        height: 8,
                      ),
                      GestureDetector(
                          onTap: () {
                            controller.applyVacancy(id);
                          }, child: const SmallButton(title: "Apply Now")),
                      const SizedBox(
                        height: 20,
                      ),
                      Text(
                        "Job Description",
                        style:
                            normalStyle.copyWith(fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(
                        height: 6.0,
                      ),
                      Html(data: description, style: {
                        "body": Style(
                            color: AppColors.black,
                            textAlign: TextAlign.start,
                            fontWeight: FontWeight.w400,
                            fontSize: FontSize(AppDimens.small.sp))
                      })
                    ],
                  ),
                ),
              ),
              const SizedBox(
                height: 30,
              ),
              Obx(()=> controller.isApplying.value?CircularProgressIndicator(color: AppColors.primary,strokeWidth: 2):Container())

            ],
          ),
        ),
      ),
    );
  }
}

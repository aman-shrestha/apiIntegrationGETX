import 'package:get/get.dart';

import '../controllers/apply_vacancy_controller.dart';

class ApplyVacancyBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<ApplyVacancyController>(
      () => ApplyVacancyController(),
    );
  }
}

import 'package:get/get.dart';
import 'package:hims_flutter/app/constants/colors.dart';
import 'package:hims_flutter/app/data/remote/api_client.dart';
import 'package:hims_flutter/app/data/remote/api_urls.dart';
import 'package:hims_flutter/app/modules/bottomNav/views/bottom_nav_view.dart';
import 'package:http/http.dart' as http;


class ApplyVacancyController extends GetxController {

  var isApplying=false.obs;
  //TODO: Implement ApplyVacancyController

  final count = 0.obs;
  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  Future<void> applyVacancy(int id) async {
    isApplying.value=true;
    // isSigningIn.value = true;
    Map<String, dynamic> requestBody = {
      "job": id,
      "application_viewed": true
    };
    Future<http.Response> response = ApiClient().postRequest(
        ApiUrls.BASE_URL + ApiUrls.APPLY_VACANCY, requestBody);
    response.then((http.Response response) {
      if (response.statusCode == 200 || response.statusCode == 201) {
        Get.offAll(()=>BottomNavView());
        Get.rawSnackbar(
            message: "Applied Successfully",
            backgroundColor: AppColors.grey.shade800,
            duration: Duration(seconds: 2),
            animationDuration: Duration(milliseconds: 100),
            snackPosition: SnackPosition.BOTTOM);
        isApplying.value=false;
      } else {
        isApplying.value=false;


      }
    });
  }
}

import 'dart:convert';

import 'package:get/get.dart';
import 'package:hims_flutter/app/data/remote/api_client.dart';
import 'package:hims_flutter/app/data/remote/api_urls.dart';
import 'package:hims_flutter/app/modules/library/models/library_list_model.dart';
import 'package:http/http.dart' as http;

class LibraryController extends GetxController {

  var libraryList=LibraryListModel().obs;
  var isLibraryListLoading=true.obs;



  //TODO: Implement DocumentsController

  @override
  void onInit() {
    getLibraryList();
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  getLibraryList() async {
    Future<http.Response> response =
    ApiClient().getRequest(ApiUrls.BASE_URL + ApiUrls.LIBRARY_LIST);
    response.then((http.Response response) {
      if (response.statusCode == 200) {
        String responseBody = utf8.decode(response
            .bodyBytes); // Decode the response body bytes to a UTF-8 string

        LibraryListModel libraryListModel =
        LibraryListModel.fromJson(jsonDecode(responseBody));
        libraryList.value = LibraryListModel(
            links: libraryListModel.links,
            total: libraryListModel.total,
            page: libraryListModel.page,
            pageSize: libraryListModel.pageSize,
            results: libraryListModel.results);

        isLibraryListLoading.value=false;
        // isBannerLoading.value = false;
      }
      else{
        isLibraryListLoading.value=false;
      }
    });
  }
}

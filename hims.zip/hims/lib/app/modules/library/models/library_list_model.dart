class LibraryListModel {
  Links? links;
  int? total;
  int? page;
  int? pageSize;
  List<Results>? results;

  LibraryListModel(
      {this.links, this.total, this.page, this.pageSize, this.results});

  LibraryListModel.fromJson(Map<String, dynamic> json) {
    links = json['links'] != null ? new Links.fromJson(json['links']) : null;
    total = json['total'];
    page = json['page'];
    pageSize = json['page_size'];
    if (json['results'] != null) {
      results = <Results>[];
      json['results'].forEach((v) {
        results!.add(new Results.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.links != null) {
      data['links'] = this.links!.toJson();
    }
    data['total'] = this.total;
    data['page'] = this.page;
    data['page_size'] = this.pageSize;
    if (this.results != null) {
      data['results'] = this.results!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Links {
  Null? next;
  Null? previous;

  Links({this.next, this.previous});

  Links.fromJson(Map<String, dynamic> json) {
    next = json['next'];
    previous = json['previous'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['next'] = this.next;
    data['previous'] = this.previous;
    return data;
  }
}

class Results {
  int? id;
  String? idx;
  String? title;
  String? author;
  Category? category;
  String? edition;
  String? createdAt;
  String? description;
  Category? section;
  Category? division;
  String? image;

  Results(
      {this.id,
        this.idx,
        this.title,
        this.author,
        this.category,
        this.edition,
        this.createdAt,
        this.description,
        this.section,
        this.division,
        this.image});

  Results.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    idx = json['idx'];
    title = json['title'];
    author = json['author'];
    category = json['category'] != null
        ? new Category.fromJson(json['category'])
        : null;
    edition = json['edition'];
    createdAt = json['created_at'];
    description = json['description'];
    section =
    json['section'] != null ? new Category.fromJson(json['section']) : null;
    division = json['division'] != null
        ? new Category.fromJson(json['division'])
        : null;
    image = json['image'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['idx'] = this.idx;
    data['title'] = this.title;
    data['author'] = this.author;
    if (this.category != null) {
      data['category'] = this.category!.toJson();
    }
    data['edition'] = this.edition;
    data['created_at'] = this.createdAt;
    data['description'] = this.description;
    if (this.section != null) {
      data['section'] = this.section!.toJson();
    }
    if (this.division != null) {
      data['division'] = this.division!.toJson();
    }
    data['image'] = this.image;
    return data;
  }
}

class Category {
  int? id;
  String? idx;
  String? title;
  String? description;
  String? createdAt;

  Category({this.id, this.idx, this.title, this.description, this.createdAt});

  Category.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    idx = json['idx'];
    title = json['title'];
    description = json['description'];
    createdAt = json['created_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['idx'] = this.idx;
    data['title'] = this.title;
    data['description'] = this.description;
    data['created_at'] = this.createdAt;
    return data;
  }
}
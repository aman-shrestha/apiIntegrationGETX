import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:hims_flutter/app/modules/documentsDetails/views/documents_details_view.dart';
import 'package:hims_flutter/app/modules/library/views/library_card_view.dart';
import 'package:hims_flutter/app/utils/date_formatter.dart';

import '../../../constants/colors.dart';
import '../../../constants/styles.dart';
import '../../../widgets/list_card.dart';
import '../../../widgets/profile_bar.dart';
import '../controllers/library_controller.dart';

class LibraryView extends GetView<LibraryController> {
  List title = [
    "Covid-19",
    "Abbreviation",
    "Methods",
  ];

  @override
  final controller = Get.put(LibraryController());
  var pageCounter = 0.obs;

  LibraryView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const PreferredSize(
          preferredSize: Size.fromHeight(80.0),
          // Set the preferred height
          child: ProfileBar(
            title: 'Library',
          )),
      body: Obx(
        () => controller.isLibraryListLoading.value
            ? CircularProgressIndicator()
            : Container(
                height: double.infinity,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Books List",
                        style: normalStyle.copyWith(fontWeight: FontWeight.w700,color: AppColors.grey),
                      ),
                      // SizedBox(
                      //   height: 34,
                      //   child: ListView.builder(
                      //     scrollDirection: Axis.horizontal,
                      //     itemCount: title.length,
                      //     itemBuilder: (BuildContext context, index) => Obx(
                      //       () => GestureDetector(
                      //         onTap: () {
                      //           pageCounter.value = index;
                      //         },
                      //         child: Padding(
                      //           padding: const EdgeInsets.only(right: 12.0),
                      //           child: Container(
                      //             alignment: Alignment.center,
                      //             decoration: BoxDecoration(
                      //               color: pageCounter.value == index
                      //                   ? AppColors.primary
                      //                   : Colors.white,
                      //               borderRadius: BorderRadius.circular(25.0),
                      //               border:
                      //                   Border.all(color: AppColors.primary),
                      //             ),
                      //             child: Padding(
                      //               padding: const EdgeInsets.symmetric(
                      //                   horizontal: 18.0),
                      //               child: Text(
                      //                 title[index],
                      //                 style: smallStyle.copyWith(
                      //                     fontWeight: pageCounter.value == index
                      //                         ? FontWeight.w700
                      //                         : FontWeight.w400,
                      //                     color: pageCounter.value == index
                      //                         ? Colors.white
                      //                         : AppColors.primary),
                      //               ),
                      //             ),
                      //           ),
                      //         ),
                      //       ),
                      //     ),
                      //   ),
                      // ),
                      const SizedBox(height: 12.0),
                      Expanded(
                        child: GridView.builder(
                            shrinkWrap: true,
                            itemCount:
                            controller.libraryList.value.results!.length,
                            gridDelegate:const SliverGridDelegateWithMaxCrossAxisExtent(
                                maxCrossAxisExtent: 200,
                                mainAxisSpacing: 12,
                                childAspectRatio: 0.96,
                                crossAxisSpacing: 12),
                            itemBuilder: (context, index) {
                              return GestureDetector(
                                onTap: (){
                                  print( controller.libraryList.value
                                      .results![index].id);
                                  Get.to(() => DocumentsDetailsView(),
                                      arguments: [
                                        controller
                                            .libraryList.value.results![index].idx,
                                      ]);
                                },

                                child: LibraryCardView(
                                  title: controller.libraryList.value
                                      .results![index].title ??
                                      "N/A",
                                  // subtitle:"Edition ${controller.libraryList.value
                                  //         .results![index].edition}",
                                  author: controller.libraryList.value
                                      .results![index].author ??
                                      "N/A",
                                  publishedDate:TimeUtils().formatDate(controller
                                      .libraryList
                                      .value
                                      .results![index]
                                      .createdAt ??
                                      "0000-00-00T00:00:00.00000") ,
                                ),
                              );
                            }),
                      )
                      // Expanded(
                      //   child: ListView.builder(
                      //     itemCount:
                      //         controller.libraryList.value.results!.length,
                      //     itemBuilder: (BuildContext context, index) => Padding(
                      //       padding: EdgeInsets.only(bottom: 8.0),
                      //       child: GestureDetector(
                      //         onTap: () {

                      //         },
                      //         child: ListCard(
                      //           image: "assets/images/book.png",
                      //           title: controller.libraryList.value
                      //                   .results![index].title ??
                      //               "N/A",
                      //           // subtitle:"Edition ${controller.libraryList.value
                      //           //         .results![index].edition}",
                      //           subtitle: TimeUtils().formatDate(controller
                      //                   .libraryList
                      //                   .value
                      //                   .results![index]
                      //                   .createdAt ??
                      //               "0000-00-00T00:00:00.00000"),
                      //         ),
                      //       ),
                      //     ),
                      //   ),
                      // ),

                      // changeView(),
                      // Expanded(child: NoticeTabBar()),
                    ],
                  ),
                ),
              ),
      ),
    );
  }
}

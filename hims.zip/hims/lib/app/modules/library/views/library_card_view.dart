import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:hims_flutter/app/constants/colors.dart';
import 'package:hims_flutter/app/constants/styles.dart';
import 'package:hims_flutter/app/utils/date_formatter.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
class LibraryCardView extends StatelessWidget {
  final String title;
  final String author;
  final String publishedDate;
  const LibraryCardView({super.key, required this.title, required this.author, required this.publishedDate});

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 0.2,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset("assets/images/library_pic.png"),
            SizedBox(height: 8),
            Text(
              title,
              style: smallStyle.copyWith(
                  fontWeight: FontWeight.w600, overflow: TextOverflow.ellipsis),
            ),
            SizedBox(height: 10),
            SizedBox(
                width: Adaptive.w(40),
                child: Text(author,style: miniStyle)),
            SizedBox(height: 2),

            Row(
              children: [
                Text(TimeUtils().calculateTimeDifference(publishedDate),style: miniStyle),
                Spacer(),
                Icon(Icons.file_download_outlined,color: AppColors.primary,)

              ],
            )

          ],
        ),
      ),
    );
  }
}

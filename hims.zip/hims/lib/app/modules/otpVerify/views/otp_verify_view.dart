import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

import 'package:get/get.dart';
import 'package:hims_flutter/app/constants/images.dart';
import 'package:hims_flutter/app/modules/userDetailForm/views/user_detail_form_view.dart';
import 'package:hims_flutter/app/widgets/button_large.dart';
import 'package:otp_text_field/otp_field.dart';
import 'package:otp_text_field/style.dart';

import '../../../constants/colors.dart';
import '../../../constants/styles.dart';
import '../controllers/otp_verify_controller.dart';

class OtpVerifyView extends GetView<OtpVerifyController> {
  const OtpVerifyView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.white,
        foregroundColor: AppColors.primary,
        elevation: 0,
      ),
      body: Container(
        color: AppColors.white,
        padding: const EdgeInsets.all(16.0),
        width: double.infinity,
        height: double.infinity,

        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: SingleChildScrollView(
            child: Column(
              children: [
                Text(
                  "OTP Verification",
                  style: mediumStyle.copyWith(fontWeight: FontWeight.w600),
                ),
                SvgPicture.asset(
                  AppImages.otpVerify,
                ),
                Text(
                  "Enter OTP",
                  style: normalStyle.copyWith(fontWeight: FontWeight.w600),
                ),
                Text(
                  "An 4 digit code has been sent to your number ",
                  style: miniStyle.copyWith(
                    fontWeight: FontWeight.w500,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(
                  height: 30,
                ),
                OTPTextField(
                  length: 4,
                  width: MediaQuery.of(context).size.width,
                  fieldStyle: FieldStyle.box,
                  fieldWidth: MediaQuery.of(context).size.width * 0.13,
                  style: TextStyle(fontSize: 17),
                  textFieldAlignment: MainAxisAlignment.spaceAround,
                  // fieldStyle: FieldStyle.underline,
                  onCompleted: (pin) {
                    print("Completed: " + pin);
                  },
                ),
                const SizedBox(
                  height: 20,
                ),
                Text(
                  "Didn't receive OTP? ",
                  style: miniStyle.copyWith(
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(
                  height: 4,
                ),
                Text(
                  "Resend OTP? ",
                  style: miniStyle.copyWith(
                      fontWeight: FontWeight.w500, color: Colors.blue),
                ),
                const SizedBox(
                  height: 28,
                ),
                GestureDetector(
                  onTap: () {
                    Get.to(()=>UserDetailFormView());
                  },
                  child: const LargeButton(title: "Verify"),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

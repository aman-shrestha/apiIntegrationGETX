import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:hims_flutter/app/constants/colors.dart';
import 'package:hims_flutter/app/constants/styles.dart';
import 'package:hims_flutter/app/modules/otpVerify/views/otp_verify_view.dart';
import 'package:hims_flutter/app/modules/userDetailForm/views/user_detail_form_view.dart';
import 'package:hims_flutter/app/widgets/button_large.dart';
import 'package:hims_flutter/app/widgets/custom_textfield.dart';

import '../controllers/signup_controller.dart';

class SignupView extends GetView<SignupController> {
  final fn=TextEditingController();
  final ln=TextEditingController();
  final email=TextEditingController();
  final pn=TextEditingController();

  final pw=TextEditingController();
  final confirmPw=TextEditingController();

  @override
  final controller=Get.put(SignupController());




  SignupView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.amber,
      appBar: AppBar(
        backgroundColor: AppColors.white,
        foregroundColor: AppColors.primary,
        elevation: 0,
      ),
      body: Container(
        height: double.infinity,
        width: double.infinity,
        color: Colors.white,
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 30, 16, 0),
            child:  Column(
              children: [
                // Image.asset("assets/images/notice.png"),
                Text(
                  "SignUp",
                  style: largeStyle.copyWith(fontWeight: FontWeight.w700),
                ),
                const SizedBox(
                  height: 10,
                ),
                Text(
                  "Enter your credentials to login to your account.",
                  style: smallStyle.copyWith(color: AppColors.grey),
                ),
                const SizedBox(
                  height: 40,
                ),
                CustomTextField(hint: "First Name", icon: Icon(Icons.message), textEditingController: fn,),
                const SizedBox(
                  height: 16,
                ),
                CustomTextField(hint: "Last Name", icon: Icon(Icons.message), textEditingController: ln,),
                const SizedBox(
                  height: 16,
                ),
                CustomTextField(hint: "Email", icon: Icon(Icons.message), textEditingController: email,),
                const SizedBox(
                  height: 16,
                ),
                CustomTextField(hint: "Phone Number", icon: Icon(Icons.phone), textEditingController: pn,),
                const SizedBox(
                  height: 16,
                ),
                // CustomTextField(hint: "Profession", icon: Icon(Icons.badge), textEditingController: profession,),
                // const SizedBox(
                //   height: 16,
                // ),
                CustomTextField(
                  hint: "Password",
                  icon: Icon(Icons.lock), textEditingController: pw,

                  // isObsecure: true,
                ),
                const SizedBox(
                  height: 16,
                ),
                CustomTextField(
                  hint: "Confirm Password",
                  icon: Icon(Icons.lock), textEditingController: confirmPw,
                  // isObsecure: true,
                ),
                const SizedBox(
                  height: 16,
                ),
                GestureDetector(
                  onTap: () {
                    controller.signup(fn.text, ln.text, pn.text, email.text, pw.text, confirmPw.text);
                    // Get.to(() => UserDetailFormView());
                  },
                  child: const LargeButton(title: "Signup"),
                ),
                const SizedBox(
                  height: 16,
                ),
                Obx(()=>controller.isSigningIn.value?CircularProgressIndicator(color: AppColors.primary):Container())
              ],
            ),
          ),
        ),
      ),
    );
  }
}

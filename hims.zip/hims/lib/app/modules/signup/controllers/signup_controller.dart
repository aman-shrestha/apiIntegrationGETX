import 'package:get/get.dart';
import 'package:hims_flutter/app/constants/colors.dart';
import 'package:hims_flutter/app/data/remote/api_client.dart';
import 'package:hims_flutter/app/data/remote/api_urls.dart';
import 'package:hims_flutter/app/modules/login/views/login_view.dart';
import 'package:hims_flutter/app/modules/userDetailForm/views/user_detail_form_view.dart';
import 'package:http/http.dart' as http;


class SignupController extends GetxController {


  var isSigningIn=false.obs;


  //TODO: Implement SignupController

  final count = 0.obs;
  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  Future<void> signup(String fn, String ln, String pn, String email, String pw,
      String cpw) async {
    isSigningIn.value = true;
    Map<String, dynamic> requestBody = {
      "first_name": fn,
      "last_name": ln,
      "phone_number": pn,
      "email": email,
      "password": pw,
      "confirm_password": cpw
    };
    Future<http.Response> response = ApiClient().postRequestWithoutToken(
        ApiUrls.BASE_URL + ApiUrls.SIGNUP, requestBody);
    response.then((http.Response response) {
      if (response.statusCode == 200 || response.statusCode == 201) {
        isSigningIn.value = false;
        Get.rawSnackbar(
            message: "Sign Up Successful",
            backgroundColor: AppColors.grey.shade800,
            duration: Duration(seconds: 2),
            animationDuration: Duration(milliseconds: 100),
            snackPosition: SnackPosition.BOTTOM);
        Get.offAll(() => LoginView());
      } else {
        isSigningIn.value = false;
      }
    });
  }
}

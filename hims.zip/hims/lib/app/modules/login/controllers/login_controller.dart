import 'dart:convert';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:hims_flutter/app/constants/colors.dart';
import 'package:hims_flutter/app/data/remote/api_client.dart';
import 'package:hims_flutter/app/data/remote/api_urls.dart';
import 'package:hims_flutter/app/modules/bottomNav/views/bottom_nav_view.dart';
import 'package:hims_flutter/app/modules/login/models/login_response_model.dart';
import 'package:hims_flutter/app/modules/userDetailForm/views/user_detail_form_view.dart';
import 'package:http/http.dart' as http;


class LoginController extends GetxController {
  //TODO: Implement LoginController

  final count = 0.obs;
  var isLogging=false.obs;
  var loginData = LoginResponseModel().obs;
  final localData = GetStorage();




  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  Future<void> login(String email, String pw) async {
    print("Login Tapped");
    isLogging.value = true;

    Map<String, dynamic> requestBody = {"email": email, "password": pw};
    Future<http.Response> response = ApiClient().postRequestWithoutToken(
        ApiUrls.BASE_URL + ApiUrls.LOGIN, requestBody);
    response.then((http.Response response) {
      if (response.statusCode == 200 || response.statusCode == 201) {
        LoginResponseModel loginResponseModel = LoginResponseModel.fromJson(jsonDecode(response.body));
        loginData.value = LoginResponseModel(
            refresh: loginResponseModel.refresh,
            access: loginResponseModel.access,
            user: loginResponseModel.user);
        storeData();
      } else {
        isLogging.value = false;
      }
    });
  }



  void storeData() {
    localData.write("isLoggedIn", true);
    localData.write("access_token", loginData.value.access);
    localData.write("full_name", loginData.value.user!.fullName);
    localData.write("email", loginData.value.user!.email);
    Get.rawSnackbar(
        message: "Successfully Logged In",
        backgroundColor: AppColors.grey.shade800,
        duration: Duration(seconds: 2),
        animationDuration: Duration(milliseconds: 100),
        snackPosition: SnackPosition.BOTTOM);
    print("access token:::"+localData.read("access_token"));
    isLogging.value = false;

    if(loginData.value.user!.hasFilledProfileInfo! && loginData.value.user!.hasFilledEducationInfo! && loginData.value.user!.hasFilledWorkExperience!){

      Get.offAll(() => BottomNavView());

    }
    else{
      Get.offAll(() => UserDetailFormView());
    }
  }

}

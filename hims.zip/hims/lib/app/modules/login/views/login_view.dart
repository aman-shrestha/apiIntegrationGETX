import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:hims_flutter/app/constants/colors.dart';
import 'package:hims_flutter/app/constants/images.dart';
import 'package:hims_flutter/app/constants/styles.dart';
import 'package:hims_flutter/app/modules/bottomNav/views/bottom_nav_view.dart';
import 'package:hims_flutter/app/widgets/checkbox_view.dart';
import 'package:hims_flutter/app/modules/signup/views/signup_view.dart';
import 'package:hims_flutter/app/widgets/button_large.dart';

import '../../../widgets/custom_textfield.dart';
import '../controllers/login_controller.dart';
import 'forgotPassword.dart';

class LoginView extends GetView<LoginController> {
  final email=TextEditingController();
  final password=TextEditingController();
  @override
  final controller=Get.put(LoginController());
   LoginView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
      height: double.infinity,
      width: double.infinity,
      decoration: const BoxDecoration(
        image: DecorationImage(
            image: AssetImage(AppImages.loginBg), fit: BoxFit.fill),
      ),
      child: Column(
        children: [
          const SizedBox(height: 100),
          Text(
            "Login",
            style: largeStyle.copyWith(
                color: Colors.white, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 24.0),
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(16.0),
              decoration: const BoxDecoration(
                  color: AppColors.white,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(20),
                      topRight: Radius.circular(20))),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    const SizedBox(
                      height: 20,
                    ),
                    Text(
                      "Enter your credentials to login to your account.",
                      style: smallStyle.copyWith(color: AppColors.grey),
                    ),
                    const SizedBox(
                      height: 28,
                    ),
                    CustomTextField(
                        hint: "Email", icon: Icon(Icons.phone), textEditingController: email),
                    const SizedBox(
                      height: 16,
                    ),
                    CustomTextField(
                      hint: "Password",
                      icon: Icon(Icons.lock), textEditingController: password,
                    ),
                    const SizedBox(
                      height: 40,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        CheckboxView(
                          title: "Remember Me", clicked: false,
                        ),
                        GestureDetector(
                          onTap: () {
                            Get.to(() => ForgotPassword());
                          },
                          child: const Text(
                            "Forgot Password?",
                            style: TextStyle(color: Colors.red),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 60,
                    ),
                    GestureDetector(
                      onTap: () {
                        controller.login(email.text, password.text);
                      },
                      child: const LargeButton(
                        title: "Log In ",
                      ),
                    ),
                    const SizedBox(
                      height: 60,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "Don't have an account?",
                          style: smallStyle.copyWith(color: AppColors.grey),
                        ),
                        GestureDetector(
                          onTap: () {
                            Get.to(() => SignupView());
                          },
                          child: const Text(
                            " Sign Up",
                            style: TextStyle(color: AppColors.blue),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                    Obx(()=> controller.isLogging.value?CircularProgressIndicator(color: AppColors.primary,strokeWidth: 2):Container())

                  ],
                ),
              ),
            ),
          )
        ],
      ),
    ));
  }
}

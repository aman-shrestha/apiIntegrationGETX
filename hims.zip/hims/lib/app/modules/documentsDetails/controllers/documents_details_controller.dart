import 'dart:convert';

import 'package:get/get.dart';
import 'package:hims_flutter/app/data/remote/api_client.dart';
import 'package:hims_flutter/app/data/remote/api_urls.dart';
import 'package:hims_flutter/app/modules/documentsDetails/models/books_model.dart';
import 'package:http/http.dart' as http;


class DocumentsDetailsController extends GetxController {
  //TODO: Implement DocumentsDetailsController

  final count = 0.obs;

  var booksList=BooksModel().obs;
  var isLoadingBook=true.obs;
  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  getBook(String idx) async {
    Future<http.Response> response =
    ApiClient().getRequest(ApiUrls.BASE_URL +ApiUrls.LIBRARY_LIST+idx+ApiUrls.GET_BOOK);
    response.then((http.Response response) {
      if (response.statusCode == 200) {
        // Parse the JSON response into a Book object
        Map<String, dynamic> responseData = json.decode(response.body);
        BooksModel books = BooksModel.fromJson(responseData);
        booksList.value=books;
        print("length of chapters::${booksList.value.chapters!.length}");
        isLoadingBook.value=false;
        // Store the book data or do whatever you need with it
        // For example, you might want to return it or store it in a state variable
      }
      else{
      }
    });
  }
}

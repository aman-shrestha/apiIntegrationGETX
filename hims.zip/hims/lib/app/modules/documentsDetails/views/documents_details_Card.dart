import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:hims_flutter/app/constants/dimens.dart';
import 'package:responsive_sizer/responsive_sizer.dart';



import '../../../constants/colors.dart';
import '../../../constants/styles.dart';

class DetailsCard extends StatelessWidget {
  final String title;
  final String subtitle;
  DetailsCard({super.key, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 2,
      borderRadius: BorderRadius.circular(8.0),
      child: Container(
        width: double.infinity,
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title,
                style: normalStyle.copyWith(fontWeight: FontWeight.w700),
              ),
              SizedBox(
                height: 20,
              ),
              Html(data: subtitle, style: {
                "body": Style(
                    color: AppColors.black,
                    textAlign: TextAlign.start,
                    fontWeight: FontWeight.w400,
                    fontSize: FontSize(AppDimens.small.sp))
              }),
            ],
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hims_flutter/app/constants/colors.dart';
import 'package:hims_flutter/app/constants/styles.dart';
import 'package:hims_flutter/app/modules/documentsDetails/models/books_model.dart';
import 'package:hims_flutter/app/modules/documentsDetails/views/documents_details_Card.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import '../controllers/documents_details_controller.dart';

class DocumentsDetailsView extends GetView<DocumentsDetailsController> {
  String idx = Get.arguments[0];
  var title = "".obs;
  var content = "".obs;

  @override
  final controller = Get.put(DocumentsDetailsController());

  var showContent = false.obs;

  DocumentsDetailsView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    controller.getBook(idx);
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Summary",
          style: TextStyle(color: AppColors.primary),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: false,
        foregroundColor: AppColors.primary,
      ),
      endDrawer: Obx(
        () => controller.isLoadingBook.value
            ? CircularProgressIndicator()
            : Container(
                color: AppColors.white,
                width: Adaptive.w(75),
                child: Column(
                  children: [chapterList(controller.booksList.value)],
                ),
              ),
      ),
      body: Obx(() => controller.isLoadingBook.value
          ? Center(child: CircularProgressIndicator())
          : controller.booksList.value.chapters!.isEmpty
              ? Center(child: Text("No Data", style: smallStyle))
              : detailsView()),
    );
  }

  detailsView() {
    title.value = controller.booksList.value.chapters![0].title ?? "N/A";
    content.value = controller.booksList.value.chapters![0].content ?? "N/A";

    return Container(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Obx(() => DetailsCard(title: title.value, subtitle: content.value)),
          ],
        ));
  }

  chapterList(BooksModel books) {
    return Expanded(
      child: ListView.builder(
        itemCount: books.chapters!.length,
        itemBuilder: (context, index) {
          final book = books.chapters![index];
          return chapterTile(book);
        },
      ),
    );
  }

  chapterTile(Chapter book) {
    return Column(
      children: [
        ListTile(
          onTap: () {
            title.value = book.title ?? "N/A";
            content.value = book.content ?? "N/A";
            Get.back();
          },
          title: Text(book.title ?? "N/A",
              style: smallStyle.copyWith(
                  color: AppColors.primary, fontWeight: FontWeight.bold)),
        ),
        book.subChapters!.isEmpty ? Container() : subchapters(book.subChapters!)
      ],
    );
  }

  subchapters(List<SubChapter> subchapters) {
    return ListView.builder(
      shrinkWrap: true,
      itemCount: subchapters.length,
      itemBuilder: (context, index) {
        final subchapter = subchapters[index];
        return subchapterTile(subchapter);
      },
    );
  }

  subchapterTile(SubChapter subChapter) {
    return Column(
      children: [
        ListTile(
          onTap: () {
            title.value = subChapter.title ?? "N/A";
            content.value = subChapter.content ?? "N/A";
            Get.back();
          },
          horizontalTitleGap: 0,
          title: Text(subChapter.title ?? "N/A"),
          leading: Icon(Icons.navigate_next_outlined),
        ),
        subChapter.subChapters!.isEmpty
            ? Container()
            : subchapters(subChapter.subChapters!)
      ],
    );
  }
}

import 'package:get/get.dart';

import '../controllers/documents_details_controller.dart';

class DocumentsDetailsBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<DocumentsDetailsController>(
      () => DocumentsDetailsController(),
    );
  }
}

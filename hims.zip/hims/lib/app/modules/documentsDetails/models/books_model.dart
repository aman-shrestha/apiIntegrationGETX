class BooksModel {
  int? id;
  String? title;
  String? author;
  String? edition;
  String? description;
  int? category;
  List<Chapter>? chapters;

  BooksModel({
    this.id,
    this.title,
    this.author,
    this.edition,
    this.description,
    this.category,
    this.chapters,
  });

  factory BooksModel.fromJson(Map<String, dynamic> json) {
    return BooksModel(
      id: json['id'],
      title: json['title'],
      author: json['author'],
      edition: json['edition'],
      description: json['description'],
      category: json['category'],
      chapters: List<Chapter>.from(
        json['chapters']?.map((chapter) => Chapter.fromJson(chapter)) ?? [],
      ),
    );
  }
}

class Chapter {
  int? id;
  String? idx;
  int? book;
  String? title;
  String? content;
  List<SubChapter>? subChapters;

  Chapter({
    this.id,
    this.idx,
    this.book,
    this.title,
    this.content,
    this.subChapters,
  });

  factory Chapter.fromJson(Map<String, dynamic> json) {
    return Chapter(
      id: json['id'],
      idx: json['idx'],
      book: json['book'],
      title: json['title'],
      content: json['content'],
      subChapters: List<SubChapter>.from(
        (json['sub_chapter'] as List?)?.whereType<Map<String, dynamic>>()?.map(
              (subChapter) => SubChapter.fromJson(subChapter),
        ) ?? [],
      ),
    );
  }
}

class SubChapter {
  int? id;
  String? idx;
  int? book;
  String? title;
  String? content;
  List<SubChapter>? subChapters;

  SubChapter({
    this.id,
    this.idx,
    this.book,
    this.title,
    this.content,
    this.subChapters,
  });

  factory SubChapter.fromJson(Map<String, dynamic> json) {
    return SubChapter(
      id: json['id'],
      idx: json['idx'],
      book: json['book'],
      title: json['title'],
      content: json['content'],
      subChapters: List<SubChapter>.from(
        (json['sub_chapter'] as List?)?.whereType<Map<String, dynamic>>()?.map(
              (subChapter) => SubChapter.fromJson(subChapter),
        ) ?? [],
      ),
    );
  }
}

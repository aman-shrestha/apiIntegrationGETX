import 'dart:convert';

import 'package:get/get.dart';
import 'package:hims_flutter/app/data/remote/api_client.dart';
import 'package:hims_flutter/app/data/remote/api_urls.dart';
import 'package:hims_flutter/app/modules/jobs/models/jobs_model.dart';
import 'package:http/http.dart' as http;


class JobsController extends GetxController {
  //TODO: Implement JobsController

  var isJobsLoading=true.obs;
  var jobsList=JobsModel().obs;


  @override
  void onInit() {
    getJobs();
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  getJobs() async {
    Future<http.Response> response =
    ApiClient().getRequest(ApiUrls.BASE_URL + ApiUrls.JOBS_LIST);
    response.then((http.Response response) {
      if (response.statusCode == 200) {
        JobsModel jobsModel =
        JobsModel.fromJson(jsonDecode(response.body));
        jobsList.value = JobsModel(
            links: jobsModel.links,
            total: jobsModel.total,
            page: jobsModel.page,
            pageSize: jobsModel.pageSize,
            results: jobsModel.results);
        isJobsLoading.value=false;
        // isBannerLoading.value = false;
      }
      else{
      }
    });
  }
}

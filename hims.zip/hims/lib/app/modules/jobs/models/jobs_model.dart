class JobsModel {
  Links? links;
  int? total;
  int? page;
  int? pageSize;
  List<Results>? results;

  JobsModel({this.links, this.total, this.page, this.pageSize, this.results});

  JobsModel.fromJson(Map<String, dynamic> json) {
    links = json['links'] != null ? new Links.fromJson(json['links']) : null;
    total = json['total'];
    page = json['page'];
    pageSize = json['page_size'];
    if (json['results'] != null) {
      results = <Results>[];
      json['results'].forEach((v) {
        results!.add(new Results.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.links != null) {
      data['links'] = this.links!.toJson();
    }
    data['total'] = this.total;
    data['page'] = this.page;
    data['page_size'] = this.pageSize;
    if (this.results != null) {
      data['results'] = this.results!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Links {
  Null? next;
  Null? previous;

  Links({this.next, this.previous});

  Links.fromJson(Map<String, dynamic> json) {
    next = json['next'];
    previous = json['previous'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['next'] = this.next;
    data['previous'] = this.previous;
    return data;
  }
}

class Results {
  int? id;
  String? idx;
  String? title;
  String? description;
  String? jobType;
  Hospital? hospital;
  Null? province;
  List<String>? skills;
  String? deadline;
  String? location;
  bool? isPublic;
  String? createdAt;

  Results(
      {this.id,
        this.idx,
        this.title,
        this.description,
        this.jobType,
        this.hospital,
        this.province,
        this.skills,
        this.deadline,
        this.location,
        this.isPublic,
        this.createdAt});

  Results.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    idx = json['idx'];
    title = json['title'];
    description = json['description'];
    jobType = json['job_type'];
    hospital = json['hospital'] != null
        ? new Hospital.fromJson(json['hospital'])
        : null;
    province = json['province'];
    skills = json['skills'].cast<String>();
    deadline = json['deadline'];
    location = json['location'];
    isPublic = json['is_public'];
    createdAt = json['created_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['idx'] = this.idx;
    data['title'] = this.title;
    data['description'] = this.description;
    data['job_type'] = this.jobType;
    if (this.hospital != null) {
      data['hospital'] = this.hospital!.toJson();
    }
    data['province'] = this.province;
    data['skills'] = this.skills;
    data['deadline'] = this.deadline;
    data['location'] = this.location;
    data['is_public'] = this.isPublic;
    data['created_at'] = this.createdAt;
    return data;
  }
}

class Hospital {
  int? id;
  String? idx;
  String? title;
  String? logo;
  String? description;
  String? domain;

  Hospital(
      {this.id,
        this.idx,
        this.title,
        this.logo,
        this.description,
        this.domain});

  Hospital.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    idx = json['idx'];
    title = json['title'];
    logo = json['logo'];
    description = json['description'];
    domain = json['domain'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['idx'] = this.idx;
    data['title'] = this.title;
    data['logo'] = this.logo;
    data['description'] = this.description;
    data['domain'] = this.domain;
    return data;
  }
}
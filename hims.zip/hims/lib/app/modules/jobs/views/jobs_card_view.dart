import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hims_flutter/app/constants/images.dart';

import '../../../constants/colors.dart';
import '../../../constants/styles.dart';

class JobsCardView extends StatelessWidget {
  final String title;
  final String hospital;
  final String location;

  final String time;

  const JobsCardView(
      {super.key,
      required this.title,
      required this.hospital,
      required this.location,
      required this.time});

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 0.2,
      borderRadius: BorderRadius.circular(8.0),

      child: Container(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: smallStyle.copyWith(fontWeight: FontWeight.w800,color: AppColors.primary),
                  ),
                  SizedBox(height: 6),
                  Text(
                    hospital,
                    style: smallStyle.copyWith(fontWeight: FontWeight.w500),
                  ),
                  SizedBox(height: 6),
                  Text(
                    location,
                    style: miniStyle.copyWith(color: AppColors.gray),
                  ),
                  SizedBox(height: 6),
                  Text(
                    time,
                    style: miniStyle,
                  ),
                ],
              ),
              Spacer(),
              SvgPicture.asset("assets/images/bookmark.svg"),
            ],
          ),
        ),
      ),
    );
  }
}

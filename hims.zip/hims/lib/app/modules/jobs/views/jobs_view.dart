import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:hims_flutter/app/modules/applyVacancy/views/apply_vacancy_view.dart';
import 'package:hims_flutter/app/modules/jobs/views/jobs_card_view.dart';
import 'package:hims_flutter/app/utils/date_formatter.dart';

import '../../../constants/colors.dart';
import '../../../constants/styles.dart';
import '../../../widgets/profile_bar.dart';
import '../../../widgets/search_field.dart';
import '../controllers/jobs_controller.dart';

class JobsView extends GetView<JobsController> {
  List title = [
    "All Jobs",
    "Saved Jobs",
    "Applied Jobs",
  ];
  @override
  final controller = Get.put(JobsController());
  var pageCounter = 0.obs;

  JobsView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: const PreferredSize(
            preferredSize: Size.fromHeight(80.0),
            // Set the preferred height
            child: ProfileBar(
              title: 'Jobs',
            )),
        body: Obx(
          () => controller.isJobsLoading.value
              ? Center(child: CircularProgressIndicator())
              : Container(
                  height: double.infinity,
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      const SearchField(text: "Search Jobs"),
                      const SizedBox(
                        height: 12,
                      ),
                      SizedBox(
                        height: 34,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: title.length,
                          itemBuilder: (BuildContext context, index) => Obx(
                            () => GestureDetector(
                              onTap: () {
                                pageCounter.value = index;
                              },
                              child: Padding(
                                padding: const EdgeInsets.only(right: 12.0),
                                child: Container(
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                    color: pageCounter.value == index
                                        ? AppColors.primary
                                        : Colors.white,
                                    borderRadius: BorderRadius.circular(25.0),
                                    border:
                                        Border.all(color: AppColors.primary),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 18.0),
                                    child: Text(
                                      title[index],
                                      style: smallStyle.copyWith(
                                          fontWeight: pageCounter.value == index
                                              ? FontWeight.w700
                                              : FontWeight.w400,
                                          color: pageCounter.value == index
                                              ? Colors.white
                                              : AppColors.primary),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 8),
                      Expanded(
                        child: ListView.builder(
                          itemCount: controller.jobsList.value.results!.length,
                          itemBuilder: (BuildContext context, index) => Padding(
                            padding: const EdgeInsets.only(bottom: 8.0),
                            child: GestureDetector(
                                onTap: () {
                                  Get.to(() => ApplyVacancyView(), arguments: [
                                    controller.jobsList.value.results![index]
                                            .title ??
                                        "N/A",
                                    controller.jobsList.value.results![index]
                                            .deadline ??
                                        "N/A",
                                    controller.jobsList.value.results![index]
                                        .description ??
                                        "N/A",
                                    controller.jobsList.value.results![index]
                                        .id
                                  ]);
                                },
                                child: JobsCardView(
                                  title: controller.jobsList.value
                                          .results![index].title ??
                                      "N/A",
                                  hospital: controller.jobsList.value
                                          .results![index].hospital!.title ??
                                      "N/A",
                                  location: controller.jobsList.value
                                          .results![index].location ??
                                      "N/A",
                                  time: TimeUtils().calculateTimeDifference(
                                      controller.jobsList.value.results![index]
                                              .createdAt ??
                                          "0000-00-00T00:00:00.00000"),
                                )),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
        ));
  }
}

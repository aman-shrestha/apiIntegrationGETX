import 'package:curved_nav_bar/curved_bar/curved_action_bar.dart';
import 'package:curved_nav_bar/fab_bar/fab_bottom_app_bar_item.dart';
import 'package:curved_nav_bar/flutter_curved_bottom_nav_bar.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:hims_flutter/app/modules/library/views/library_view.dart';

import '../../../constants/colors.dart';
import '../../dashboard/views/dashboard_view.dart';
import '../../jobs/views/jobs_view.dart';
import '../../notice/views/notice_view.dart';
import '../../qr/views/qr_view.dart';
import '../controllers/bottom_nav_controller.dart';

class BottomNavView extends GetView<BottomNavController> {
  var pageIndex = 0.obs;
  final pages = [
    DashboardView(),
    NoticeView(),
    const QrView(),
    LibraryView(),
    JobsView()
  ];
  BottomNavView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return CurvedNavBar(
      actionButton: CurvedActionBar(
          onTab: (value) {
            /// perform action here
            print(value);
          },
          activeIcon: Container(
            padding: const EdgeInsets.all(8),
            decoration: const BoxDecoration(
                color: AppColors.primary, shape: BoxShape.circle),
            child: const Padding(
              padding: EdgeInsets.all(8.0),
              child: Icon(
                Icons.qr_code,
                color: Colors.white,
              ),
            ),
          )),
      activeColor: AppColors.primary,
      navBarBackgroundColor: Colors.white,
      inActiveColor: Colors.grey,
      appBarItems: [
        FABBottomAppBarItem(
            activeIcon: const Icon(Icons.pie_chart,color: AppColors.primary),
            inActiveIcon: const Icon(Icons.pie_chart_outline,color: AppColors.grey),
            text: 'Dashboard'),
        FABBottomAppBarItem(
            activeIcon: const Icon(Icons.book_sharp,color: AppColors.primary),
            inActiveIcon: const Icon(Icons.book_outlined,color: AppColors.grey),
            text: 'Notice'),
        FABBottomAppBarItem(
            activeIcon: const Icon(Icons.my_library_books_rounded,color: AppColors.primary),
            inActiveIcon: const Icon(Icons.my_library_books_outlined,color: AppColors.grey),
            text: 'Library'),
        FABBottomAppBarItem(
            activeIcon: const Icon(Icons.badge,color: AppColors.primary),
            inActiveIcon: const Icon(Icons.badge_outlined,color: AppColors.grey),
            text: 'Jobs'),
      ],
      bodyItems: [DashboardView(), NoticeView(), LibraryView(), JobsView()],
      actionBarView: const QrView(),
    );
  
  }
}

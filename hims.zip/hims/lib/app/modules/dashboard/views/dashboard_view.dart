import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import 'package:get/get.dart';
import 'package:hims_flutter/app/constants/colors.dart';
import 'package:hims_flutter/app/constants/styles.dart';
import 'package:hims_flutter/app/modules/dashboard/views/hospital/hospitals_view.dart';
import 'package:hims_flutter/app/modules/dashboard/views/medication/medications_view.dart';
import 'package:hims_flutter/app/modules/dashboard/views/my_hospital_view.dart';
import 'package:hims_flutter/app/modules/dashboard/views/vitals/vitals.dart';
import 'package:hims_flutter/app/modules/profile/views/profile_view.dart';

import 'package:responsive_sizer/responsive_sizer.dart';

import '../../../widgets/profile_bar.dart';
import '../../../widgets/search_field.dart';
import '../controllers/dashboard_controller.dart';

class DashboardView extends GetView<DashboardController> {
  List title = ["Hospitals", "Vitals", "Medications"];

  // List title = ["Hospitals", "Vitals", "Medications", "My Hospitals"];
  var pageCounter = 0.obs;

  DashboardView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Obx(
      () => Scaffold(
          appBar: const PreferredSize(
              preferredSize: Size.fromHeight(80.0),
              // Set the preferred height
              child: ProfileBar(
                title: 'Hi, Rishek',
              )),
          body: Container(
            padding: EdgeInsets.symmetric(horizontal: 16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 16.0),

                SizedBox(
                  height: 34,
                  child: ListView.builder(
                    shrinkWrap: true,
                    scrollDirection: Axis.horizontal,
                    itemCount: title.length,
                    itemBuilder: (BuildContext context, index) => Padding(
                      padding: const EdgeInsets.only(right: 8.0),
                      child: GestureDetector(
                        onTap: () {
                          pageCounter.value = index;
                        },
                        child: Obx(
                          () => Container(
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: pageCounter.value == index
                                  ? AppColors.primary
                                  : AppColors.transparent,
                              borderRadius: BorderRadius.circular(25.0),
                              border: Border.all(color: AppColors.primary),
                            ),
                            child: Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 18.0),
                              child: Text(
                                title[index],
                                style: smallStyle.copyWith(
                                    fontWeight: pageCounter.value == index
                                        ? FontWeight.w700
                                        : FontWeight.w400,
                                    color: pageCounter.value == index
                                        ? AppColors.white
                                        : AppColors.primary),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                changeView(),
              ],
            ),
          )),
    );
  }

  changeView() {
    if (pageCounter.value == 0) {
      return HospitalsView();
    } else if (pageCounter.value == 1) {
      return Vitals();
    } else if (pageCounter.value == 2) {
      return MedicationsView();
    }
    // else {
    //   return MyHospitalView();
    // }
  }
}

import 'package:flutter/material.dart';
import 'package:hims_flutter/app/constants/images.dart';
import 'package:hims_flutter/app/modules/dashboard/views/facility_card.dart';
import 'package:hims_flutter/app/modules/dashboard/views/service_card.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

import '../../../constants/colors.dart';
import '../../../constants/styles.dart';

class MyHospitalView extends StatelessWidget {
  List image = [
    AppIcons.bedIcon,
    AppIcons.icuIcon,
    AppIcons.cylinderIcon,
    AppIcons.ambulanceIcon,
  ];
  List title = [
    "Available Beds",
    "ICU Room",
    "Oxygen Cylinder",
    "Available Ambulance",
  ];
  List no = [
    "1",
    "2",
    "1",
    "2",
  ];
  MyHospitalView({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Bir Hospital",
              style: mediumStyle.copyWith(
                  color: AppColors.primary, fontWeight: FontWeight.bold),
            ),
            SizedBox(
              height: 20,
            ),
            SizedBox(
              height: Adaptive.h(24),
              child: GridView.builder(
                itemCount: image.length,
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                    maxCrossAxisExtent: 200,
                    mainAxisSpacing: 8,
                    childAspectRatio: 2,
                    crossAxisSpacing: 8),
                itemBuilder: (BuildContext context, index) => FacilityCard(
                  image: image[index],
                  title: title[index],
                  no: no[index],
                ),
              ),
            ),
            Container(
              // height: Adaptive.h(40),
              // height: Adaptive.h(20),
              height: MediaQuery.of(context).size.height * 0.4,
              child: ServicesCard(),
            ),
          ],
        ),
      ),
    );
  }
}

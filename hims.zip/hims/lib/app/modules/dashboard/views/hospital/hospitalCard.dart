import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:hims_flutter/app/constants/dimens.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

import '../../../../constants/colors.dart';
import '../../../../constants/styles.dart';



class HospitalCard extends StatelessWidget {
  final String title;
  final String subtitle;
  HospitalCard({super.key, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 0.2,
        borderRadius: BorderRadius.circular(12),
        child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12)
        ),
        child: Padding(
          padding: EdgeInsets.fromLTRB(8, 12, 8, 12),
          child: Row(
            children: [
              Image.asset(
                "assets/images/notice.png",
                height: 60,
              ),
              SizedBox(
                width: 10,
              ),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                      style: smallStyle.copyWith(
                          fontWeight: FontWeight.w600,
                          color: Color.fromRGBO(7, 45, 75, 1)),
                    ),


                  ],
                ),
              ),
              IconButton(
                  onPressed: () {},
                  icon: Icon(
                    Icons.chevron_right,
                    color: AppColors.primary,
                  ))
            ],
          ),
        ),
      ),
    );
  }
}

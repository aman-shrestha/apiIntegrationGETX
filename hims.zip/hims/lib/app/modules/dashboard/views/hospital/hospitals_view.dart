import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:hims_flutter/app/modules/dashboard/controllers/dashboard_controller.dart';

import '../../../../constants/styles.dart';
import 'hospitalCard.dart';

class HospitalsView extends StatelessWidget {
  List title = [
    "Teaching Hospital",
    "Teaching Hospital",
    "Teaching Hospital",
  ];
  List subtitle = [
    "Qorem ipsum dolor sit amet, consectetur dipiscing elit.Qorem ipsum dolor sit amet",
    "Qorem ipsum dolor sit amet, consectetur dipiscing elit.Qorem ipsum dolor sit amet",
    "Qorem ipsum dolor sit amet, consectetur dipiscing elit.Qorem ipsum dolor sit amet",
  ];

  final controller=Get.put(DashboardController());


  HospitalsView({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Obx(()=>controller.isHospitalListLoading.value?Center(child: CircularProgressIndicator()):
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 20),
            ListView.builder(
              physics: NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              itemCount: controller.hospitalList.length,
              itemBuilder: (BuildContext context, index) => Padding(
                padding: const EdgeInsets.only(bottom: 8.0),
                child: HospitalCard(
                  title: controller.hospitalList[index].title!,
                  subtitle: controller.hospitalList[index].description!,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

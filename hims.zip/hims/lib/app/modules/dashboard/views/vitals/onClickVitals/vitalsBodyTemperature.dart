import 'package:flutter/material.dart';

import '../../../../../constants/colors.dart';
import '../../../../../constants/styles.dart';
import 'onClickVitalsCard/vitalsTemperatureCard.dart';

class VitalsBodyTemperature extends StatelessWidget {
  const VitalsBodyTemperature({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Body Temperature",
          style: normalStyle.copyWith(
            color: AppColors.primary,
          ),
        ),
        backgroundColor: Colors.white,
        centerTitle: false,
        foregroundColor: AppColors.primary,
      ),
      body: Container(
        height: double.infinity,
        width: double.infinity,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [VitalsTemperatureCard()],
          ),
        ),
      ),
    );
  }
}

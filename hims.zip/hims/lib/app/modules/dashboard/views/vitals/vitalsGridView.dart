import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/route_manager.dart';
import 'package:hims_flutter/app/modules/dashboard/controllers/dashboard_controller.dart';

import '../../../../constants/colors.dart';
import '../../../../constants/styles.dart';
import 'onClickVitals/vitalsBloodGroup.dart';
import 'onClickVitals/vitalsBodyPressure.dart';
import 'onClickVitals/vitalsBodyTemperature.dart';
import 'onClickVitals/vitalsBodyWeight.dart';

class VitalsGridView extends StatelessWidget {

  List image = [
    "assets/icons/blood_group.svg",
    "assets/icons/body_weight.svg",
    "assets/icons/temperature.svg",
    "assets/icons/blood_pressure.svg",
  ];
  List title = [
    "Blood Group",
    "Body Weight",
    "Temperature",
    "Blood Pressure",
  ];


  List gridColors=[
    const Color(0xffFFE2E5),
    const Color(0xffFFF4DE),
    const Color(0xffDCFCE7),
    const Color(0xffF3E8FF),


  ];
  final List<String> vitalsList;

  VitalsGridView({super.key, required this.vitalsList});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      itemCount: image.length,
      gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
          maxCrossAxisExtent: 200,
          mainAxisSpacing: 12,
          childAspectRatio: 1.1,
          crossAxisSpacing: 12),
      itemBuilder: (BuildContext context, index) => GestureDetector(
        onTap: () {
          if (index == 0) {
            Get.to(() => VitalsBloodGroup());
          } else if (index == 1) {
            Get.to(() => const VitalsBodyWeight());
          } else if (index == 2) {
            Get.to(() => const VitalsBodyTemperature());
          } else if (index == 3) {
            Get.to(() => const VitalsBodyPressure());
          }
        },
        child: Container(
          decoration: BoxDecoration(
              color: gridColors[index],

              borderRadius: BorderRadius.circular(16)
          ),
          padding: EdgeInsets.all(16.0),

          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SvgPicture.asset(image[index]),
              const SizedBox(
                height: 16.0,
              ),
              Text(
                vitalsList[index],
                style: normalStyle.copyWith(
                    fontWeight: FontWeight.bold),
              ),
              const SizedBox(
                height: 6.0,
              ),
              Text(
                title[index],
                style: smallStyle.copyWith(color: AppColors.grey.shade600),
              ),
              const SizedBox(
                height: 6.0,
              ),
              Text(
                "Update",
                style: miniStyle.copyWith(color: AppColors.primary),
              ),

            ],
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:hims_flutter/app/widgets/button_large.dart';

import '../../../../constants/colors.dart';
import '../../../../constants/styles.dart';
import 'onClickVitals/ListWheelScrollView.dart';
import 'onClickVitals/onClickVitalsCard/vitalsBodyWeightCard.dart';

class Sys extends StatelessWidget {
  const Sys({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Body Weight",
          style: normalStyle.copyWith(
            color: AppColors.primary,
          ),
        ),
        backgroundColor: Colors.white,
        centerTitle: false,
        foregroundColor: AppColors.primary,
      ),
      body: Container(
        height: double.infinity,
        width: double.infinity,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 40, 16, 40),
                  child: Column(
                    children: [
                      Text(
                        "Add Body Pressure",
                        style:
                            mediumStyle.copyWith(fontWeight: FontWeight.w600),
                      ),
                      SizedBox(
                        height: 26,
                      ),
                      Container(
                        height: MediaQuery.of(context).size.height * 0.3,
                        child: MyListWheelScrollView(),
                      ),
                      SizedBox(
                        height: 30,
                      ),
                      LargeButton(title: "Add")
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

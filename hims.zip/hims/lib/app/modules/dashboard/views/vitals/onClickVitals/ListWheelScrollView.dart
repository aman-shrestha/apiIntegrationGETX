import 'package:flutter/material.dart';

import '../../../../../constants/colors.dart';


class MyListWheelScrollView extends StatefulWidget {
  @override
  _MyListWheelScrollViewState createState() => _MyListWheelScrollViewState();
}

class _MyListWheelScrollViewState extends State<MyListWheelScrollView> {
  int selectedValue = 0;
  final List<String> items = [
    'Item 1',
    'Item 2',
    'Item 3',
    'Item 4',
    'Item 5',
    'Item 6',
    'Item 7',
    'Item 8',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: ListWheelScrollView(
          itemExtent: 50,
          onSelectedItemChanged: (int index) {
            setState(() {
              selectedValue = index;
            });
          },
          children: items
              .asMap()
              .map((index, item) => MapEntry(
                    index,
                    ListTile(
                      title: Text(
                        item,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 20,
                          color: index == selectedValue
                              ? Colors.black // Change the selected text color
                              : AppColors.gray,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ))
              .values
              .toList(),
        ),
      ),
    );
  }
}

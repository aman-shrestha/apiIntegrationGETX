import 'package:flutter/material.dart';

import '../../../../../constants/colors.dart';
import '../../../../../constants/styles.dart';

import 'onClickVitalsCard/vitalsBodyPressureCard.dart';

class VitalsBodyPressure extends StatelessWidget {
  const VitalsBodyPressure({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Body Pressure",
          style: normalStyle.copyWith(
            color: AppColors.primary,
          ),
        ),
        backgroundColor: Colors.white,
        centerTitle: false,
        foregroundColor: AppColors.primary,
      ),
      body: Container(
        height: double.infinity,
        width: double.infinity,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [VitalsBodyPressureCard()],
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:get/route_manager.dart';
import 'package:hims_flutter/app/widgets/button_large.dart';

import '../../../../../../constants/colors.dart';
import '../../../../../../constants/styles.dart';
import '../../sys.dart';

class VitalsBodyPressureCard extends StatelessWidget {
  var sys = "120";
  var dia = "80";
  var pulse = "60";
  VitalsBodyPressureCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 40, 16, 40),
        child: Column(
          children: [
            Text(
              "Add Body Pressure",
              style: mediumStyle.copyWith(fontWeight: FontWeight.w600),
            ),
            SizedBox(
              height: 50,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                GestureDetector(
                  onTap: () {
                    Get.to(() => Sys());
                  },
                  child: Text(
                    'sys\nmmHG',
                    style: normalStyle.copyWith(
                        color: AppColors.primary, fontWeight: FontWeight.w600),
                  ),
                ),
                Text(
                  sys,
                  style: normalStyle.copyWith(fontWeight: FontWeight.w600),
                ),
              ],
            ),
            SizedBox(
              height: 24,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                GestureDetector(
                  onTap: () {
                    Get.to(() => Sys());
                  },
                  child: Text(
                    'DIA\nmmHG',
                    style: normalStyle.copyWith(
                        color: AppColors.primary, fontWeight: FontWeight.w600),
                  ),
                ),
                Text(
                  dia,
                  style: normalStyle.copyWith(fontWeight: FontWeight.w600),
                ),
              ],
            ),
            SizedBox(
              height: 24,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                GestureDetector(
                  onTap: () {
                    Get.to(() => Sys());
                  },
                  child: Text(
                    'PULSE\nmmHG',
                    style: normalStyle.copyWith(
                        color: AppColors.primary, fontWeight: FontWeight.w600),
                  ),
                ),
                Text(
                  pulse,
                  style: normalStyle.copyWith(fontWeight: FontWeight.w600),
                ),
              ],
            ),
            SizedBox(
              height: 24,
            ),
            LargeButton(title: "Save"),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/route_manager.dart';
import 'package:hims_flutter/app/modules/dashboard/controllers/dashboard_controller.dart';
import '../../../../constants/styles.dart';
import 'vitalsGridView.dart';

class Vitals extends StatelessWidget {
  final controller=Get.put(DashboardController());
  Vitals({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Obx(()=>controller.isVitalsLoading.value?CircularProgressIndicator():
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 16.0,
            ),
            Text(
              "Vital Details",
              style: normalStyle.copyWith(fontWeight: FontWeight.w700),
            ),
            SizedBox(
              height: 20,
            ),
            VitalsGridView(vitalsList:controller.vitals),
          ],
        ),
      ),
    );
  }
}

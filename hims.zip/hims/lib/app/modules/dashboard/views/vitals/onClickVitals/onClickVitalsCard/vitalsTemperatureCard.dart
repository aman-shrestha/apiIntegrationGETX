import 'package:flutter/material.dart';
import 'package:hims_flutter/app/widgets/button_large.dart';

import '../../../../../../constants/styles.dart';
import '../ListWheelScrollView.dart';

class VitalsTemperatureCard extends StatelessWidget {
  const VitalsTemperatureCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 40, 16, 40),
        child: Column(
          children: [
            Text(
              "Add Body Temperature",
              style: mediumStyle.copyWith(fontWeight: FontWeight.w600),
            ),
            SizedBox(
              height: 26,
            ),
            Container(
              height: MediaQuery.of(context).size.height * 0.3,
              child: MyListWheelScrollView(),
            ),
            SizedBox(
              height: 30,
            ),
            LargeButton(title: "Add"),
          ],
        ),
      ),
    );
  }
}

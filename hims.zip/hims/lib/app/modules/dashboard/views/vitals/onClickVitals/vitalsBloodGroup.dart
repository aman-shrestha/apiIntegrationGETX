import 'package:flutter/material.dart';

import '../../../../../constants/colors.dart';
import '../../../../../constants/styles.dart';
import 'onClickVitalsCard/vitalsBloodGroupCard.dart';

class VitalsBloodGroup extends StatefulWidget {
  VitalsBloodGroup({super.key});

  @override
  State<VitalsBloodGroup> createState() => _VitalsBloodGroupState();
}

class _VitalsBloodGroupState extends State<VitalsBloodGroup> {
  int selectedValue = 0;
  var age = 25;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Blood Group",
          style: normalStyle.copyWith(
            color: AppColors.primary,
          ),
        ),
        elevation: 0,
        backgroundColor: Colors.white,
        centerTitle: false,
        foregroundColor: AppColors.primary,
      ),
      body: Container(
        height: double.infinity,
        width: double.infinity,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [VitalsBloodGroupCard()],
          ),
        ),
      ),
    );
  }
}

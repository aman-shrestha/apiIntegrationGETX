import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

import '../../../../constants/colors.dart';
import '../../../../constants/styles.dart';

class MedicationCard extends StatefulWidget {
  final String title;
  final String subtitle;
  final String date;

  const MedicationCard(
      {super.key,
        required this.title,
        required this.subtitle,
        required this.date});

  @override
  State<MedicationCard> createState() => _MedicationCardState();
}

class _MedicationCardState extends State<MedicationCard> {
  String dropdownvalue = 'Item 1';
  var items = [
    'Edit',
    'Delete',

  ];

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 0.2,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.all(8.0),
        height: 80,
        child: Row(
          children: [
            Container(
              width: 56,
              height: 56,
              decoration: const ShapeDecoration(
                color: Color(0xFFF5F5FE),
                shape: OvalBorder(),
              ),
              child: Center(
                child:     SvgPicture.asset("assets/icons/medication_icon.svg"),
              ),

            ),
            const SizedBox(width: 10,),
            Expanded(
              child:  Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.title,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.black,
                      fontSize: 18,
                      fontFamily: 'Inter',
                      fontWeight: FontWeight.w600,
                      height: 0,
                    ),
                  ),
                  SizedBox(height: 5,),
                  SizedBox(
                    width: 270,
                    child: Text(
                      widget.subtitle,
                      style: const TextStyle(
                        color: Color(0xFF595959),
                        fontSize: 12,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400,
                        height: 0,
                      ),
                      overflow: TextOverflow.ellipsis,
                      maxLines: 2,
                    ),
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 15),
              child: Align(
                alignment: Alignment.topRight,
                child: DropdownButton(
                  underline: Container(),
                  padding: EdgeInsets.zero,
                  elevation: 1,


                  // Initial Value
                  //  value: dropdownvalue,

                  // Down Arrow Icon
                  icon: const Icon(Icons.more_horiz),

                  // Array list of items
                  items: items.map((String items) {
                    return DropdownMenuItem(
                      value: items,
                      child: Text(items,style: smallStyle,),
                    );
                  }).toList(),
                  // After selecting the desired option,it will
                  // change button value to selected value
                  onChanged: (String? newValue) {
                    setState(() {
                      dropdownvalue = newValue!;
                    });
                  },
                ),
              ),
            ),

          ],
        ),
      ),
    );
  }
}
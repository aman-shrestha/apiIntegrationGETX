import 'package:flutter/material.dart';
import 'package:get/route_manager.dart';

class CustomTextFieldMedication extends StatelessWidget {
  const CustomTextFieldMedication({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 42,
      child: TextFormField(
        decoration: InputDecoration(
          border: OutlineInputBorder(),
          filled: true,
          fillColor: Colors.white,
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Color.fromRGBO(208, 213, 221, 1)),
            borderRadius: BorderRadius.circular(12.0),
          ),
        ),
      ),
    );
  }
}

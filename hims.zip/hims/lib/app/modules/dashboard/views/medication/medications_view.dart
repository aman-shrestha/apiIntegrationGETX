import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hims_flutter/app/constants/colors.dart';

import '../../../../constants/styles.dart';
import 'medicationsCard.dart';
import 'uploadDocument.dart';

class MedicationsView extends StatelessWidget {
  List title = [
    "Sugar",
    "Sugar",
    "Sugar",
    "Sugar",

  ];
  List subtitle = [
    "Lab Report",
    "Lab Report",
    "Lab Report",
    "Lab Report",

  ];
  List date = [
    "Aug 20,2022",
    "Aug 20,2022",
    "Aug 20,2022",
    "Aug 20,2022",

  ];
  MedicationsView({super.key});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: 16.0),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Attachments (4)",
                style: normalStyle.copyWith(fontWeight: FontWeight.w700),
              ),
              Container(
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(100),
                      color: AppColors.primary),
                  child: IconButton(
                      onPressed: () {
                        Get.to(() => UploadDocument());
                      },
                      icon: Icon(
                        Icons.add,
                        color: Colors.white,
                      ))),
            ],
          ),
          SizedBox(height: 10.0),
          Expanded(
            child: ListView.builder(
              itemCount: title.length,
              itemBuilder: (BuildContext context, index) => Padding(
                padding: const EdgeInsets.only(bottom: 8.0),
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 8.0),
                  child: MedicationCard(
                      title: title[index],
                      subtitle: subtitle[index],
                      date: date[index]),
                ),
              ),
            ),
          ),
        ],
      ),
    );
    // floatingActionButton: FloatingActionButton(
    //   onPressed: () {
    //     // Add your action here
    //     Get.to(() => UploadDocument());
    //   },
    //   child: Icon(Icons.add),
    // ),
    // floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
  }
}

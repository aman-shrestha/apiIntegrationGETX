import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hims_flutter/app/constants/images.dart';

import '../../../constants/styles.dart';

class ServicesCard extends StatelessWidget {
  List image = [
    AppIcons.generalIcon,
    AppIcons.oxygenIcon,
    AppIcons.ambulanceBlueIcon,
    AppIcons.opdWardIcon,
    AppIcons.medicineIcon,
    AppIcons.labIcon,
  ];
  List title = [
    "General",
    "Oxygen",
    "Ambulance",
    "OPD Ward",
    "Medicine",
    "Lab",
  ];

  ServicesCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Padding(
            padding: const EdgeInsets.only(
              top: 16,
              left: 20,
            ),
            child: Text(
              "Services",
              style: normalStyle.copyWith(fontWeight: FontWeight.w600),
            ),
          ),
          GridView.builder(
              physics: const NeverScrollableScrollPhysics(),
              itemCount: image.length,
              shrinkWrap: true,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisSpacing: 10,
                crossAxisCount: 3,
              ),
              itemBuilder: (BuildContext context, index) => Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SvgPicture.asset(image[index]),
                      const SizedBox(
                        height: 5,
                      ),
                      Text(
                        title[index],
                        style: miniStyle,
                      ),
                    ],
                  ))
        ]));
  }
}

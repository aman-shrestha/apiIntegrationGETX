import 'dart:convert';

import 'package:get/get.dart';
import 'package:hims_flutter/app/data/remote/api_client.dart';
import 'package:hims_flutter/app/data/remote/api_urls.dart';
import 'package:hims_flutter/app/modules/dashboard/models/hospital_list_model.dart';
import 'package:hims_flutter/app/modules/dashboard/models/vitals_model.dart';
import 'package:http/http.dart' as http;



class DashboardController extends GetxController {


  RxList<HospitalListModel> hospitalList = <HospitalListModel>[].obs;
  var isHospitalListLoading=true.obs;
  var isVitalsLoading=true.obs;

  var vitalsData=VitalsModel().obs;
  var bloodGroup="".obs;
  var bodyWeight=0.0.obs;
  var temperature=0.0.obs;
  var bp=0.obs;
  List<String> vitals=[
  ];




  //TODO: Implement DashboardController

  final count = 0.obs;
  @override
  void onInit() {
    getHospitals();
    getVitals();
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  getHospitals() async {
    Future<http.Response> response =
    ApiClient().getRequest(ApiUrls.BASE_URL + ApiUrls.HOSPITALS_LIST);
    response.then((http.Response response) {
      if (response.statusCode == 200) {
        List<dynamic> jsonList = json.decode(response.body);
        hospitalList.assignAll(jsonList.map((json) => HospitalListModel.fromJson(json)).toList());
        print("length:::"+hospitalList.length.toString());
        isHospitalListLoading.value=false;
        // isBannerLoading.value = false;
      }
      else{
      }
    });
  }

  getVitals() async {
    vitals.clear();
    Future<http.Response> response =
    ApiClient().getRequest(ApiUrls.BASE_URL + ApiUrls.GET_VITALS);
    response.then((http.Response response) {
      if (response.statusCode == 200) {
        print("got vitals response");
        VitalsModel vitalsModel =
        VitalsModel.fromJson(jsonDecode(response.body));
        vitalsData.value = VitalsModel(
            links: vitalsModel.links,
            total: vitalsModel.total,
            page: vitalsModel.page,
            pageSize: vitalsModel.pageSize,
            results: vitalsModel.results);
        if(vitalsData.value.results!.isEmpty){
          print("vital is empty");

          bloodGroup.value="_";
          bodyWeight.value=0;
          temperature.value=0;
          bp.value=0;
          vitals.add(bloodGroup.value.toString());
          vitals.add(bodyWeight.value.toString());
          vitals.add(temperature.value.toString());
          vitals.add(bp.value.toString());
          isVitalsLoading.value=false;

        }
        else{
          print("vital is not empty");
          bloodGroup.value=vitalsData.value.results![0].bloodGroup ?? "_";
          bodyWeight.value=vitalsData.value.results![0].bodyWeight ?? 0;
          temperature.value=vitalsData.value.results![0].bodyTemperature ?? 0;
          bp.value=vitalsData.value.results![0].heartRate ?? 0;
          print(" bp.value::"+bp.value.toString());

          vitals.add(bloodGroup.value.toString());
          vitals.add(bodyWeight.value.toString());
          vitals.add(temperature.value.toString());
          vitals.add(bp.value.toString());
          print("vitals length::"+vitals.length.toString());
          isVitalsLoading.value=false;

        }
      }
      else{
      }
    });
  }



}

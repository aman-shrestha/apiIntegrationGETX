class HospitalListModel {
  int? id;
  String? idx;
  String? title;
  String? logo;
  String? description;

  HospitalListModel(
      {this.id, this.idx, this.title, this.logo, this.description});

  HospitalListModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    idx = json['idx'];
    title = json['title'];
    logo = json['logo'];
    description = json['description'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['idx'] = this.idx;
    data['title'] = this.title;
    data['logo'] = this.logo;
    data['description'] = this.description;
    return data;
  }
}
import 'dart:convert';

import 'package:get/get.dart';
import 'package:hims_flutter/app/data/remote/api_client.dart';
import 'package:hims_flutter/app/data/remote/api_urls.dart';
import 'package:hims_flutter/app/modules/notice/models/notice_model.dart';
import 'package:http/http.dart' as http;


class NoticeController extends GetxController {
  //TODO: Implement NoticeController

  var isNoticeLoading=true.obs;
  var noticeList=NoticeModel().obs;


  @override
  void onInit() {
    getNotices();
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  getNotices() async {
    Future<http.Response> response =
    ApiClient().getRequest(ApiUrls.BASE_URL + ApiUrls.NOTICE_LIST);
    response.then((http.Response response) {
      if (response.statusCode == 200) {
        NoticeModel noticeModel =
        NoticeModel.fromJson(jsonDecode(response.body));
        noticeList.value = NoticeModel(
            links: noticeModel.links,
            total: noticeModel.total,
            page: noticeModel.page,
            pageSize: noticeModel.pageSize,
            results: noticeModel.results);
        isNoticeLoading.value=false;
        // isBannerLoading.value = false;
      }
      else{
        isNoticeLoading.value=false;
      }
    });
  }
}

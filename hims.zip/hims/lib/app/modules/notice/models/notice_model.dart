class NoticeModel {
  Links? links;
  int? total;
  int? page;
  int? pageSize;
  List<Results>? results;

  NoticeModel({this.links, this.total, this.page, this.pageSize, this.results});

  factory NoticeModel.fromJson(Map<String, dynamic> json) {
    return NoticeModel(
      links: json['links'] != null ? Links.fromJson(json['links']) : null,
      total: json['total'],
      page: json['page'],
      pageSize: json['page_size'],
      results: List<Results>.from(json['results'].map((result) => Results.fromJson(result))),
    );
  }
}

class Links {
  dynamic next;
  dynamic previous;

  Links({
    this.next,
    this.previous,
  });

  factory Links.fromJson(Map<String, dynamic> json) {
    return Links(
      next: json['next'],
      previous: json['previous'],
    );
  }
}

class Results {
  int? id;
  String? idx;
  List<int>? hospital;
  List<int>? user;
  String? title;
  String? description;
  bool? isPublic;
  bool? forAdmin;
  bool? forManager;
  String? createdAt;
  List<dynamic>? province;
  dynamic? expiresAfter;
  bool? isEmail;
  bool? isNotification;
  bool? isNotice;
  String? publishedBy;

  Results(
      {this.id,
        this.idx,
        this.hospital,
        this.user,
        this.title,
        this.description,
        this.isPublic,
        this.forAdmin,
        this.forManager,
        this.createdAt,
        this.province,
        this.expiresAfter,
        this.isEmail,
        this.isNotification,
        this.isNotice,
        this.publishedBy});

  factory Results.fromJson(Map<String, dynamic> json) {
    return Results(
      id: json['id'],
      idx: json['idx'],
      hospital: (json['hospital'] as List<dynamic>?)?.cast<int>() ?? [],
      user: (json['user'] as List<dynamic>?)?.cast<int>() ?? [],
      title: json['title'],
      description: json['description'],
      isPublic: json['is_public'], // Provide a default value (e.g., false) here
      forAdmin: json['for_admin'],
      forManager: json['for_manager'],
      createdAt: json['created_at'],
      province: (json['province'] as List<dynamic>?) ?? [],
      expiresAfter: json['expires_after'],
      isEmail: json['is_email'],
      isNotification: json['is_notification'],
      isNotice: json['is_notice'],
      publishedBy: json['published_by'],

    );
  }
}

// class NoticeModel {
//   Links? links;
//   int? total;
//   int? page;
//   int? pageSize;
//   List<Result>? results;
//
//   NoticeModel({
//     this.links,
//     this.total,
//     this.page,
//     this.pageSize,
//     this.results,
//   });
//

//

//
// class Result {
//   int? id;
//   String? idx;
//   List<int>? hospital;
//   List<int>? user;
//   String? title;
//   String? description;
//   bool? isPublic;
//   bool? forAdmin;
//   bool? forManager;
//   String? createdAt;
//   List<dynamic>? province;
//   dynamic? expiresAfter;
//   bool? isEmail;
//   bool? isNotification;
//   bool? isNotice;
//
//   Result({
//     required this.id,
//     required this.idx,
//     required this.hospital,
//     required this.user,
//     required this.title,
//     required this.description,
//     required this.isPublic,
//     required this.forAdmin,
//     required this.forManager,
//     required this.createdAt,
//     required this.province,
//     required this.expiresAfter,
//     required this.isEmail,
//     required this.isNotification,
//     required this.isNotice,
//   });
//


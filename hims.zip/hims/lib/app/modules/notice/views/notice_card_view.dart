import 'package:flutter/material.dart';
import 'package:hims_flutter/app/constants/colors.dart';
import 'package:hims_flutter/app/constants/styles.dart';
import 'package:hims_flutter/app/utils/date_formatter.dart';
import 'package:responsive_sizer/responsive_sizer.dart';


class NoticeCardView extends StatelessWidget {
  final String title;
  final String date;
  final String publishedBy;
  const NoticeCardView({super.key, required this.title, required this.date, required this.publishedBy});

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 0.2,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 8.0,vertical: 18.0),
        child: Row(
          children: [
            Container(
              padding: EdgeInsets.all(8.0),
              height: 50,
              width: 50,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(6),
                color: AppColors.primary,
              ),
              child: Text(
                "Dec 05",
                style: smallStyle.copyWith(color: Colors.white),
                textAlign: TextAlign.center,
              ),
            ),
            SizedBox(
              width: 16.0,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: Adaptive.w(60),
                  child: Text(
                    title,
                    overflow: TextOverflow.ellipsis,
                    maxLines: 1,
                    style: smallStyle.copyWith(fontWeight: FontWeight.bold),
                  ),
                ),
                SizedBox(height: 4.0),
                // Html(data: subtitle,
                //     style: {
                //   "body": Style(
                //     maxLines: 2,
                //       color: AppColors.black,
                //       textAlign: TextAlign.start,
                //       fontWeight: FontWeight.w400,
                //       fontSize: FontSize(AppDimens.small.sp))
                // }),
                SizedBox(height: 4.0),
                Text(
                  "Published By: $publishedBy",
                  style: miniStyle.copyWith(
                      fontWeight: FontWeight.w500, color: AppColors.primary),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

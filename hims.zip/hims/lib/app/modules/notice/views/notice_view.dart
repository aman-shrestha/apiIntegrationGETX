import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

import 'package:get/get.dart';
import 'package:hims_flutter/app/modules/notice/views/notice_card_view.dart';
import 'package:hims_flutter/app/modules/noticeDetails/views/notice_details_view.dart';
import 'package:hims_flutter/app/utils/date_formatter.dart';
import 'package:hims_flutter/app/widgets/list_card.dart';
import 'package:hims_flutter/app/widgets/profile_bar.dart';
import 'package:hims_flutter/app/widgets/search_field.dart';

import '../../../constants/colors.dart';
import '../../../constants/styles.dart';
import '../controllers/notice_controller.dart';

class NoticeView extends GetView<NoticeController> {
  List title = [
    "All",
    "Latest News",
    "Press",
  ];

  var pageCounter = 0.obs;
  @override
  final controller=Get.put(NoticeController());

  NoticeView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const PreferredSize(
          preferredSize: Size.fromHeight(80.0),
          // Set the preferred height
          child: ProfileBar(
            title: 'Notice',
          )),
      body: Obx(()=>controller.isNoticeLoading.value?Center(child: CircularProgressIndicator()):
        Container(
          height: double.infinity,
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Notices",
                  style: normalStyle.copyWith(fontWeight: FontWeight.w700,color: AppColors.grey),
                ),
                // const SearchField(text: "Recent announcements, events"),
                // const SizedBox(
                //   height: 12,
                // ),
                // SizedBox(
                //   height: 34,
                //   child: ListView.builder(
                //     scrollDirection: Axis.horizontal,
                //     itemCount: title.length,
                //     itemBuilder: (BuildContext context, index) => Obx(
                //       () => GestureDetector(
                //         onTap: () {
                //           pageCounter.value = index;
                //         },
                //         child: Padding(
                //           padding: const EdgeInsets.only(right: 12.0),
                //           child: Container(
                //             alignment: Alignment.center,
                //             decoration: BoxDecoration(
                //               color: pageCounter.value == index
                //                   ? AppColors.primary
                //                   : Colors.white,
                //               borderRadius: BorderRadius.circular(25.0),
                //               border: Border.all(color: AppColors.primary),
                //             ),
                //             child: Padding(
                //               padding:
                //                   const EdgeInsets.symmetric(horizontal: 18.0),
                //               child: Text(
                //                 title[index],
                //                 style: smallStyle.copyWith(
                //                     fontWeight: pageCounter.value == index
                //                         ? FontWeight.w700
                //                         : FontWeight.w400,
                //                     color: pageCounter.value == index
                //                         ? Colors.white
                //                         : AppColors.primary),
                //               ),
                //             ),
                //           ),
                //         ),
                //       ),
                //     ),
                //   ),
                // ),
                const SizedBox(height: 12.0),
                Expanded(
                  child: ListView.builder(
                    itemCount: controller.noticeList.value.results!.length,
                    itemBuilder: (BuildContext context, index) => Padding(
                      padding: EdgeInsets.only(bottom: 8.0),
                      child: GestureDetector(
                        onTap: () {
                          Get.to(() => NoticeDetailsView());
                        },
                        child: NoticeCardView(title: controller.noticeList.value.results![index].title ?? "N/A",date: TimeUtils().formatDate(controller.noticeList.value.results![index].createdAt ?? "0000-00-00T00:00:00.00000"), publishedBy: controller.noticeList.value.results![index].publishedBy ?? "N/A")


                        // ListCard(
                        //     image: "assets/images/notice.png",
                        //     title:controller.noticeList.value.results![index].title ?? "N/A",
                        //     // subtitle:controller.noticeList.value.results![index].description ?? "N/A",
                        //     subtitle: TimeUtils().formatDate(controller.noticeList.value.results![index].createdAt ?? "0000-00-00T00:00:00.00000")),
                      ),
                    ),
                  ),
                ),

                // changeView(),
                // Expanded(child: NoticeTabBar()),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

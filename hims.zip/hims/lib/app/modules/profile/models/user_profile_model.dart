class UserProfileModel {
  Links? links;
  int? total;
  int? page;
  int? pageSize;
  List<Results>? results;

  UserProfileModel(
      {this.links, this.total, this.page, this.pageSize, this.results});

  UserProfileModel.fromJson(Map<String, dynamic> json) {
    links = json['links'] != null ? new Links.fromJson(json['links']) : null;
    total = json['total'];
    page = json['page'];
    pageSize = json['page_size'];
    if (json['results'] != null) {
      results = <Results>[];
      json['results'].forEach((v) {
        results!.add(new Results.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.links != null) {
      data['links'] = this.links!.toJson();
    }
    data['total'] = this.total;
    data['page'] = this.page;
    data['page_size'] = this.pageSize;
    if (this.results != null) {
      data['results'] = this.results!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Links {
  Null? next;
  Null? previous;

  Links({this.next, this.previous});

  Links.fromJson(Map<String, dynamic> json) {
    next = json['next'];
    previous = json['previous'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['next'] = this.next;
    data['previous'] = this.previous;
    return data;
  }
}

class Results {
  int? id;
  String? idx;
  User? user;
  String? insuranceNumber;
  String? location;
  int? experience;
  String? birthDate;
  String? nationality;
  String? country;
  String? maritalStatus;
  String? qrCode;

  Results(
      {this.id,
        this.idx,
        this.user,
        this.insuranceNumber,
        this.location,
        this.experience,
        this.birthDate,
        this.nationality,
        this.country,
        this.maritalStatus,
        this.qrCode});

  Results.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    idx = json['idx'];
    user = json['user'] != null ? new User.fromJson(json['user']) : null;
    insuranceNumber = json['insurance_number'];
    location = json['location'];
    experience = json['experience'];
    birthDate = json['birth_date'];
    nationality = json['nationality'];
    country = json['country'];
    maritalStatus = json['marital_status'];
    qrCode = json['qr_code'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['idx'] = this.idx;
    if (this.user != null) {
      data['user'] = this.user!.toJson();
    }
    data['insurance_number'] = this.insuranceNumber;
    data['location'] = this.location;
    data['experience'] = this.experience;
    data['birth_date'] = this.birthDate;
    data['nationality'] = this.nationality;
    data['country'] = this.country;
    data['marital_status'] = this.maritalStatus;
    data['qr_code'] = this.qrCode;
    return data;
  }
}

class User {
  int? id;
  String? idx;
  String? firstName;
  Null? middleName;
  String? lastName;
  String? email;
  String? phoneNumber;

  User(
      {this.id,
        this.idx,
        this.firstName,
        this.middleName,
        this.lastName,
        this.email,
        this.phoneNumber});

  User.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    idx = json['idx'];
    firstName = json['first_name'];
    middleName = json['middle_name'];
    lastName = json['last_name'];
    email = json['email'];
    phoneNumber = json['phone_number'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['idx'] = this.idx;
    data['first_name'] = this.firstName;
    data['middle_name'] = this.middleName;
    data['last_name'] = this.lastName;
    data['email'] = this.email;
    data['phone_number'] = this.phoneNumber;
    return data;
  }
}
class UserEducationModel {
  Links? links;
  int? total;
  int? page;
  int? pageSize;
  List<Results>? results;

  UserEducationModel(
      {this.links, this.total, this.page, this.pageSize, this.results});

  UserEducationModel.fromJson(Map<String, dynamic> json) {
    links = json['links'] != null ? new Links.fromJson(json['links']) : null;
    total = json['total'];
    page = json['page'];
    pageSize = json['page_size'];
    if (json['results'] != null) {
      results = <Results>[];
      json['results'].forEach((v) {
        results!.add(new Results.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.links != null) {
      data['links'] = this.links!.toJson();
    }
    data['total'] = this.total;
    data['page'] = this.page;
    data['page_size'] = this.pageSize;
    if (this.results != null) {
      data['results'] = this.results!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Links {
  Null? next;
  Null? previous;

  Links({this.next, this.previous});

  Links.fromJson(Map<String, dynamic> json) {
    next = json['next'];
    previous = json['previous'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['next'] = this.next;
    data['previous'] = this.previous;
    return data;
  }
}

class Results {
  int? id;
  String? idx;
  User? user;
  String? fieldOfStudy;
  String? startDate;
  String? endDate;
  String? instituteName;
  String? levelOfEducation;
  String? percentage;

  Results(
      {this.id,
        this.idx,
        this.user,
        this.fieldOfStudy,
        this.startDate,
        this.endDate,
        this.instituteName,
        this.levelOfEducation,
        this.percentage});

  Results.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    idx = json['idx'];
    user = json['user'] != null ? new User.fromJson(json['user']) : null;
    fieldOfStudy = json['field_of_study'];
    startDate = json['start_date'];
    endDate = json['end_date'];
    instituteName = json['institute_name'];
    levelOfEducation = json['level_of_education'];
    percentage = json['percentage'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['idx'] = this.idx;
    if (this.user != null) {
      data['user'] = this.user!.toJson();
    }
    data['field_of_study'] = this.fieldOfStudy;
    data['start_date'] = this.startDate;
    data['end_date'] = this.endDate;
    data['institute_name'] = this.instituteName;
    data['level_of_education'] = this.levelOfEducation;
    data['percentage'] = this.percentage;
    return data;
  }
}

class User {
  int? id;
  String? idx;
  String? firstName;
  Null? middleName;
  String? lastName;
  String? email;
  String? phoneNumber;

  User(
      {this.id,
        this.idx,
        this.firstName,
        this.middleName,
        this.lastName,
        this.email,
        this.phoneNumber});

  User.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    idx = json['idx'];
    firstName = json['first_name'];
    middleName = json['middle_name'];
    lastName = json['last_name'];
    email = json['email'];
    phoneNumber = json['phone_number'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['idx'] = this.idx;
    data['first_name'] = this.firstName;
    data['middle_name'] = this.middleName;
    data['last_name'] = this.lastName;
    data['email'] = this.email;
    data['phone_number'] = this.phoneNumber;
    return data;
  }
}
import 'dart:convert';

import 'package:get/get.dart';
import 'package:hims_flutter/app/data/remote/api_client.dart';
import 'package:hims_flutter/app/data/remote/api_urls.dart';
import 'package:hims_flutter/app/modules/profile/models/user_education_model.dart';
import 'package:hims_flutter/app/modules/profile/models/user_experience_model.dart';
import 'package:hims_flutter/app/modules/profile/models/user_profile_model.dart';
import 'package:http/http.dart' as http;


class ProfileController extends GetxController {

  var userProfileData=UserProfileModel().obs;
  var userEducationData=UserEducationModel().obs;
  var userExperienceData=UserExperienceModel().obs;

  var isProfileDataLoading=true.obs;

  //TODO: Implement ProfileController

  final count = 0.obs;
  @override
  void onInit() {
    getProfile();
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  getProfile() async {
    Future<http.Response> response =
    ApiClient().getRequest(ApiUrls.BASE_URL + ApiUrls.USER_PROFILE_INFO);
    response.then((http.Response response) {
      if (response.statusCode == 200) {
        UserProfileModel userProfileModel =
        UserProfileModel.fromJson(jsonDecode(response.body));
        userProfileData.value = UserProfileModel(
            links: userProfileModel.links,
            total: userProfileModel.total,
            page: userProfileModel.page,
            pageSize: userProfileModel.pageSize,
            results: userProfileModel.results);
        print("got profile");
        getEducation();
      }
      else{
        isProfileDataLoading.value=false;

      }
    });
  }


  getEducation() async {
    Future<http.Response> response =
    ApiClient().getRequest(ApiUrls.BASE_URL + ApiUrls.USER_EDUCATION_INFO);
    response.then((http.Response response) {
      if (response.statusCode == 200) {
        UserEducationModel userEducationModel =
        UserEducationModel.fromJson(jsonDecode(response.body));
        userEducationData.value = UserEducationModel(
            links: userEducationModel.links,
            total: userEducationModel.total,
            page: userEducationModel.page,
            pageSize: userEducationModel.pageSize,
            results: userEducationModel.results);
        print("got education");

        getExperience();
      }
      else{
        isProfileDataLoading.value=false;

      }
    });
  }


  getExperience() async {
    Future<http.Response> response =
    ApiClient().getRequest(ApiUrls.BASE_URL + ApiUrls.USER_EXPERIENCE_INFO);
    response.then((http.Response response) {
      if (response.statusCode == 200) {
        UserExperienceModel userExperienceModel =
        UserExperienceModel.fromJson(jsonDecode(response.body));
        userExperienceData.value = UserExperienceModel(
            links: userExperienceModel.links,
            total: userExperienceModel.total,
            page: userExperienceModel.page,
            pageSize: userExperienceModel.pageSize,
            results: userExperienceModel.results);
        print("got experience");

        isProfileDataLoading.value=false;
      }
      else{
        isProfileDataLoading.value=false;

      }
    });
  }

}

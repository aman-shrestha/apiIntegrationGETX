import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:hims_flutter/app/modules/login/views/login_view.dart';

import '../../../constants/colors.dart';
import '../../../constants/styles.dart';
import '../controllers/profile_controller.dart';
import 'profileCard/appreciation.dart';
import 'profileCard/contactDetailsCard.dart';
import 'profileCard/educationCard.dart';
import 'profileCard/personalInfoCard.dart';
import 'profileCard/workExperienceCard.dart';

class ProfileView extends GetView<ProfileController> {
  var showPersonalInfo = false.obs;
  var showContactDetails = false.obs;
  var showWorkExperience = false.obs;
  var showEducation = false.obs;
  var showAppreciation = false.obs;

  // List icon = [
  //   "assets/images/personalInfo.svg",
  //   "assets/images/contactDetails.svg",
  //   "assets/images/workExperience.svg",
  //   "assets/images/education.svg",
  //   "assets/images/appreciation.svg",
  // ];
  // List title = [
  //   "Personal Info",
  //   "Contact Details",
  //   "Work Experience",
  //   "Education",
  //   "Appreciation",
  // ];
  List<String> personalInfoTitle = [
    "Insurance Number",
    "Location",
    "Experience",
    "Birth Date",
    "Nationality",
    "Country",
    "Marital Status",
  ];
  List<String> personalInfoSubtitle = [
    "1234",
    "Nepal",
    "1 year ",
    "01NOV, 2000",
    "Nepali",
    "Nepali",
    "-",
  ];
  List<String> contactTitle = [
    "Phone Number",
    "Email Address",
  ];
  List<String> contactSubtitle = [
    "123456789",
    "abc@gmail.com",
  ];
  List<String> workExperienceTitle = [
    "Manager",
    "Designer",
  ];
  List<String> workExperienceSubtitle = [
    "Amazon Inc Jan,2015",
    "Amazon Inc Jan,2015",
  ];
  List<String> educationTitle = [
    "Information Technology",
  ];
  List<String> educationSubtitle = [
    "University of Oxford",
  ];
  List<String> appreciationTitle = [
    "Information Technology",
  ];
  List<String> appreciationSubtitle = [
    "University of Oxford",
  ];
  final localData = GetStorage();


  @override
  final controller = Get.put(ProfileController());

  ProfileView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(""),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
      ),
      body: Obx(
        () => controller.isProfileDataLoading.value
            ? const Center(child: CircularProgressIndicator())
            : Container(
                color: AppColors.white,
                child: SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
                    child: Obx(
                      () => Column(
                        children: [
                          Stack(
                            alignment: Alignment.bottomCenter,
                            children: <Widget>[
                              Container(
                                margin: const EdgeInsets.only(top: 20),
                                width: double.infinity,
                                height:
                                    MediaQuery.of(context).size.height * 0.24,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(16),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.grey.withOpacity(0.5),
                                        spreadRadius: 0.2,
                                        blurRadius: 0.2,
                                        offset: const Offset(
                                            0, 1), // Changes position of shadow
                                      ),
                                    ],
                                    color: Colors.white),
                              ),
                              Positioned(
                                bottom: 40,
                                child: Column(
                                  children: [
                                    Container(
                                      width: MediaQuery.of(context).size.width *
                                          0.3,
                                      height:
                                          MediaQuery.of(context).size.height *
                                              0.14,
                                      decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(100.0),
                                      ),
                                      child: Image.asset(
                                        "assets/images/user.png",
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                    const SizedBox(height: 8.0),
                                    Text("${controller.userProfileData.value.results![0]
                                        .user!.firstName!} ${controller.userProfileData.value.results![0]
                                        .user!.lastName!}" ,
                                      style: mediumStyle.copyWith(
                                          fontWeight: FontWeight.w700),
                                    ),
                                    const SizedBox(height: 6.0),
                                    Text(controller.userExperienceData.value.results![0]
                                        .position ?? "N/A",
                                      style: normalStyle.copyWith(
                                          fontWeight: FontWeight.bold,
                                          color: AppColors.gray),
                                    ),
                                  ],
                                ),
                              )
                            ],
                          ),
                          const SizedBox(
                            height: 16.0,
                          ),
                          GestureDetector(
                            onTap: () {
                              showPersonalInfo.value = !showPersonalInfo.value;
                            },
                            child: PersonalInfoCard(
                              icon: "assets/images/personalInfo.svg",
                              title: "Personal Info",
                              personalInfoTitle: personalInfoTitle,
                              personalInfoSubtitle: [
                                controller.userProfileData.value.results![0]
                                        .insuranceNumber ??
                                    "N/A",
                                controller.userProfileData.value.results![0]
                                        .location ??
                                    "N/A",
                                controller.userProfileData.value.results![0]
                                    .experience
                                    .toString(),
                                controller.userProfileData.value.results![0]
                                        .birthDate ??
                                    "N/A",
                                controller.userProfileData.value.results![0]
                                        .nationality ??
                                    "N/A",
                                controller.userProfileData.value.results![0]
                                        .country ??
                                    "N/A",
                                controller.userProfileData.value.results![0]
                                        .maritalStatus ??
                                    "N/A",
                              ],
                              index: 0,
                              isVisible: showPersonalInfo.value,
                            ),
                          ),
                          const SizedBox(
                            height: 16.0,
                          ),
                          GestureDetector(
                            onTap: () {
                              showContactDetails.value =
                                  !showContactDetails.value;
                            },
                            child: ContactDetailsCard(
                              icon: "assets/images/contactDetails.svg",
                              title: "Contact Details",
                              contactTitle: contactTitle,
                              contactSubtitle: [
                                controller.userProfileData.value.results![0]
                                        .user!.phoneNumber ??
                                    "N/A",
                                controller.userProfileData.value.results![0]
                                        .user!.email ??
                                    "N/A",
                              ],
                              isVisible: showContactDetails.value,
                            ),
                          ),
                          const SizedBox(
                            height: 16.0,
                          ),
                          GestureDetector(
                            onTap: () {
                              showWorkExperience.value =
                                  !showWorkExperience.value;
                            },
                            child: WorkExperienceCard(
                              icon: "assets/images/workExperience.svg",
                              title: "Work Experience",
                              workExperienceTitle: [controller.userExperienceData.value.results![0]
                                  .position ??
                                  "N/A"],
                              workExperienceSubtitle: [controller.userExperienceData.value.results![0]
                                  .location ??
                                  "N/A"],
                              isVisible: showWorkExperience.value,
                            ),
                          ),
                          const SizedBox(
                            height: 16.0,
                          ),
                          GestureDetector(
                            onTap: () {
                              showEducation.value = !showEducation.value;
                            },
                            child: EducatoinCard(
                              icon: "assets/images/education.svg",
                              title: "Education",
                              educationTitle: [controller.userEducationData.value.results![0]
                                  .fieldOfStudy ??
                                  "N/A"],
                              educationSubtitle: [controller.userEducationData.value.results![0]
                                  .instituteName ??
                                  "N/A"],
                              isVisible: showEducation.value,
                            ),
                          ),
                          const SizedBox(
                            height: 16.0,
                          ),
                          GestureDetector(
                            onTap: () {
                              showAppreciation.value = !showAppreciation.value;
                            },
                            child: AppreciationCard(
                              icon: "assets/images/appreciation.svg",
                              title: "Appreciation",
                              appreciationTitle: appreciationTitle,
                              appreciationSubtitle: appreciationSubtitle,
                              isVisible: showAppreciation.value,
                            ),
                          ),
                          const SizedBox(
                            height: 16.0,
                          ),
                          GestureDetector(
                            onTap: (){
                              localData.erase();

                              Get.offAll(LoginView());
                            },
                            child: Container(
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(16),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.withOpacity(0.5),
                                      spreadRadius: 0.2,
                                      blurRadius: 0.2,
                                      offset: const Offset(
                                          0, 1), // Changes position of shadow
                                    ),
                                  ],
                                  color: Colors.white),
                              child:
                              Padding(
                                padding: const EdgeInsets.fromLTRB(16, 20, 16, 20),
                                child: Row(
                                  children: [
                                    Icon(Icons.logout,color: AppColors.primary,),
                                    SizedBox(
                                      width: 16,
                                    ),
                                    Text(
                                      "Logout",
                                      style: smallStyle.copyWith(
                                          fontWeight: FontWeight.w700,
                                          color: Color.fromRGBO(21, 11, 61, 1)),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              ),
      ),
    );
  }
}

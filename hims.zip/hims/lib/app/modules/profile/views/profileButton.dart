import 'package:flutter/material.dart';

import '../../../constants/styles.dart';


class ProfileButton extends StatelessWidget {
  final String title;
  const ProfileButton({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 51,
      width: 200,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12.0),
        color: Color.fromRGBO(38, 92, 192, 1),
      ),
      child: Center(
        child: Text(
          title,
          style: normalStyle.copyWith(
              fontWeight: FontWeight.w600, color: Colors.white),
        ),
      ),
    );
  }
}

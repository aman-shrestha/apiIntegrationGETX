import 'package:flutter/material.dart';
import 'package:get/route_manager.dart';

import '../../../../../constants/styles.dart';
import '../../customTextFieldProfile.dart';
import '../../dateRow.dart';
import '../../fileUploaderProfile.dart';
import '../../profileButton.dart';

class AddAppreciationTraining extends StatelessWidget {
  const AddAppreciationTraining({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: double.infinity,
      width: double.infinity,
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Training Title",
              style: smallStyle.copyWith(fontWeight: FontWeight.w700),
            ),
            SizedBox(height: 8),
            CustomTextFieldProfile(),
            SizedBox(height: 8),
            Text(
              "Institute Name",
              style: smallStyle.copyWith(fontWeight: FontWeight.w700),
            ),
            SizedBox(height: 8),
            CustomTextFieldProfile(),
            SizedBox(height: 8),
            DateRow(),
            SizedBox(height: 8),
            Text(
              "Upload Documents",
              style: smallStyle.copyWith(fontWeight: FontWeight.w700),
            ),
            SizedBox(height: 8),
            FileUploadProfile(),
            SizedBox(height: 13),
            Center(child: ProfileButton(title: "Save"))
          ],
        ),
      ),
    );
  }
}

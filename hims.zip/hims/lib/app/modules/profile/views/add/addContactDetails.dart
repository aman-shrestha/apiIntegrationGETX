import 'package:flutter/material.dart';
import 'package:hims_flutter/app/widgets/profile_bar_profileView.dart';

import '../../../../constants/colors.dart';
import '../../../../constants/styles.dart';
import '../customTextFieldProfile.dart';
import '../dateRow.dart';
import '../profileButton.dart';

class AddContactDetails extends StatelessWidget {
  const AddContactDetails({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(50.0),
        child: ProfileBarProfileView(title: "Add Contact Detail"),
      ),
      body: Container(
        height: double.infinity,
        width: double.infinity,
        color: Colors.white,
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Text(
                    "Add Contact Details",
                    style: mediumStyle.copyWith(fontWeight: FontWeight.w700),
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  "Phone Number",
                  style: smallStyle.copyWith(fontWeight: FontWeight.w700),
                ),
                SizedBox(height: 8),
                CustomTextFieldProfile(),
                SizedBox(height: 8),
                Text(
                  "Email Address",
                  style: smallStyle.copyWith(fontWeight: FontWeight.w700),
                ),
                SizedBox(height: 8),
                CustomTextFieldProfile(),
                SizedBox(height: 150),
                Center(child: ProfileButton(title: "Save"))
              ],
            ),
          ),
        ),
      ),
    );
  }
}

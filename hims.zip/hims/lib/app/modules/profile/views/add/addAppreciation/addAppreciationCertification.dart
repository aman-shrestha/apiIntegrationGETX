import 'package:flutter/material.dart';


import '../../../../../constants/styles.dart';
import '../../customTextFieldProfile.dart';
import '../../fileUploaderProfile.dart';
import '../../profileButton.dart';

class AddAppreciationCertificate extends StatelessWidget {
  const AddAppreciationCertificate({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: double.infinity,
      width: double.infinity,
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Certification Name",
              style: smallStyle.copyWith(fontWeight: FontWeight.w700),
            ),
            SizedBox(height: 8),
            CustomTextFieldProfile(),
            SizedBox(height: 8),
            Text(
              "Certification Number",
              style: smallStyle.copyWith(fontWeight: FontWeight.w700),
            ),
            SizedBox(height: 8),
            CustomTextFieldProfile(),
            SizedBox(height: 8),
            Text(
              "Certification Date",
              style: smallStyle.copyWith(fontWeight: FontWeight.w700),
            ),
            SizedBox(height: 8),
            CustomTextFieldProfile(),
            SizedBox(height: 8),
            Text(
              "Upload Documents",
              style: smallStyle.copyWith(fontWeight: FontWeight.w700),
            ),
            SizedBox(height: 8),
            FileUploadProfile(),
            SizedBox(height: 13),
            Center(child: ProfileButton(title: "Save"))
          ],
        ),
      ),
    );
  }
}

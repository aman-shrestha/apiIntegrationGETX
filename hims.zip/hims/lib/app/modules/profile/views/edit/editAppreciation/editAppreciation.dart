import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hims_flutter/app/widgets/profile_bar_profileView.dart';

import '../../../../../constants/colors.dart';
import '../../../../../constants/styles.dart';
import '../../profileButton.dart';
import 'editAppreciationCertificate.dart';
import 'editAppreciationTraining.dart';

class ProfileEditAppreciation extends StatelessWidget {
  var count = 0.obs;
  ProfileEditAppreciation({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: Size.fromHeight(50.0),
          child: ProfileBarProfileView(title: "Edit Appreciation")),
      body: Container(
        height: double.infinity,
        width: double.infinity,
        color: Colors.white,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Text(
                  "Edit Appreciation",
                  style: mediumStyle.copyWith(fontWeight: FontWeight.w700),
                ),
              ),
              SizedBox(height: 10),
              Text(
                "I'd like to edit",
                style: smallStyle.copyWith(fontWeight: FontWeight.w700),
              ),
              SizedBox(height: 8),
              Obx(
                () => Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    GestureDetector(
                        onTap: () {
                          count.value = 0;
                        },
                        child: Row(
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color:
                                      Colors.black, // Specify the border color
                                  width: 1.0, // Specify the border width
                                ),
                              ),
                              child: Icon(
                                Icons.circle,
                                color: count.value == 0
                                    ? AppColors.primary
                                    : Colors.white,
                              ),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Text("Certificate"),
                          ],
                        )),
                    GestureDetector(
                        onTap: () {
                          count.value = 1;
                        },
                        child: Row(
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color:
                                      Colors.black, // Specify the border color
                                  width: 1.0, // Specify the border width
                                ),
                              ),
                              child: Icon(
                                Icons.circle,
                                color: count.value == 1
                                    ? AppColors.primary
                                    : Colors.white,
                              ),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Text("Training"),
                          ],
                        )),
                  ],
                ),
              ),
              SizedBox(height: 8),
              Obx(
                () => count.value == 0
                    ? Expanded(
                        child: EditAppreciationCertificate(),
                      )
                    : Expanded(
                        child: EditAppreciationTraining(),
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

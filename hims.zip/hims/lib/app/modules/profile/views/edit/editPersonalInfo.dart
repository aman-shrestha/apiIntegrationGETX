import 'package:flutter/material.dart';
import 'package:hims_flutter/app/widgets/profile_bar_profileView.dart';

import '../../../../constants/colors.dart';
import '../../../../constants/styles.dart';
import '../customTextFieldProfile.dart';
import '../dateRow.dart';
import '../profileButton.dart';

class ProfileEditPersonalInfo extends StatelessWidget {
  const ProfileEditPersonalInfo({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: Size.fromHeight(50.0),
          child: ProfileBarProfileView(title: "Edit Personal Info")),
      body: Container(
        height: double.infinity,
        width: double.infinity,
        color: Colors.white,
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Text(
                    "Edit Personal Info",
                    style: mediumStyle.copyWith(fontWeight: FontWeight.w700),
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  "Name",
                  style: smallStyle.copyWith(fontWeight: FontWeight.w700),
                ),
                SizedBox(height: 8),
                CustomTextFieldProfile(),
                SizedBox(height: 8),
                Text(
                  "Position",
                  style: smallStyle.copyWith(fontWeight: FontWeight.w700),
                ),
                SizedBox(height: 8),
                CustomTextFieldProfile(),
                SizedBox(height: 8),
                Text(
                  "Location",
                  style: smallStyle.copyWith(fontWeight: FontWeight.w700),
                ),
                SizedBox(height: 8),
                CustomTextFieldProfile(),
                SizedBox(height: 8),
                //ROW TO BE ADDED
                DateRow(),
                SizedBox(height: 8),
                Text(
                  "Nationality",
                  style: smallStyle.copyWith(fontWeight: FontWeight.w700),
                ),
                SizedBox(height: 8),
                CustomTextFieldProfile(),
                SizedBox(height: 8),
                Text(
                  "Country",
                  style: smallStyle.copyWith(fontWeight: FontWeight.w700),
                ),
                SizedBox(height: 8),
                CustomTextFieldProfile(),
                SizedBox(height: 8),
                Text(
                  "Marital Status",
                  style: smallStyle.copyWith(fontWeight: FontWeight.w700),
                ),
                SizedBox(height: 8),
                CustomTextFieldProfile(),
                SizedBox(height: 16),
                Center(child: ProfileButton(title: "Save"))
              ],
            ),
          ),
        ),
      ),
    );
  }
}

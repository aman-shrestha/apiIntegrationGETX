import 'package:flutter/material.dart';
import 'package:hims_flutter/app/widgets/profile_bar_profileView.dart';

import '../../../../constants/colors.dart';
import '../../../../constants/styles.dart';
import '../../../../widgets/checkbox.dart';
import '../customTextFieldProfile.dart';
import '../dateRow.dart';
import '../profileButton.dart';

class EditExperience extends StatelessWidget {
  const EditExperience({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: Size.fromHeight(50.0),
          child: ProfileBarProfileView(title: "Edit Experience")),
      body: Container(
        height: double.infinity,
        width: double.infinity,
        color: Colors.white,
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Text(
                    "Edit Experience",
                    style: mediumStyle.copyWith(fontWeight: FontWeight.w700),
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  "Job title",
                  style: smallStyle.copyWith(fontWeight: FontWeight.w700),
                ),
                SizedBox(height: 8),
                CustomTextFieldProfile(),
                SizedBox(height: 8),
                Text(
                  "Company",
                  style: smallStyle.copyWith(fontWeight: FontWeight.w700),
                ),
                SizedBox(height: 8),
                CustomTextFieldProfile(),
                SizedBox(height: 8),
                DateRow(),
                SizedBox(height: 8),
                Row(
                  children: [
                    CheckboxButton(),
                    Expanded(child: Text("This is my position now")),
                  ],
                ),
                SizedBox(height: 8),
                Text(
                  "Description",
                  style: smallStyle.copyWith(fontWeight: FontWeight.w700),
                ),
                SizedBox(height: 8),
                SizedBox(
                  child: TextField(
                    autofocus: true,

                    maxLines: 5, // <--- maxLines
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      enabledBorder: OutlineInputBorder(
                        borderSide:
                            BorderSide(color: Color.fromRGBO(208, 213, 221, 1)),
                        borderRadius: BorderRadius.circular(12.0),
                      ),
                      filled: true,
                      fillColor: Colors.white,
                    ),
                  ),
                ),
                SizedBox(height: 16),
                Center(child: ProfileButton(title: "Save"))
              ],
            ),
          ),
        ),
      ),
    );
  }
}

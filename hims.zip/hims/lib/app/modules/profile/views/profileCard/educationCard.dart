import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/route_manager.dart';

import '../../../../constants/styles.dart';
import '../add/addEducation.dart';
import '../edit/editEducation.dart';


class EducatoinCard extends StatelessWidget {
  final List<String> educationTitle;
  final List<String> educationSubtitle;
  final bool isVisible;
  final String icon;
  final String title;
  EducatoinCard({
    super.key,
    required this.icon,
    required this.title,
    required this.educationTitle,
    required this.educationSubtitle,
    required this.isVisible,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 0.2,
              blurRadius: 0.2,
              offset: const Offset(
                  0, 1), // Changes position of shadow
            ),
          ],
          color: Colors.white),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
        child: Column(
          children: [
            Row(
              children: [
                SvgPicture.asset(icon),
                SizedBox(
                  width: 16,
                ),
                Text(
                  title,
                  style: smallStyle.copyWith(
                      fontWeight: FontWeight.w700,
                      color: Color.fromRGBO(21, 11, 61, 1)),
                ),
                Spacer(),
                SvgPicture.asset("assets/images/Add.svg")
                // Column(
                //   children: [
                //     GestureDetector(
                //         onTap: () {
                //           Get.to(() => AddEducation());
                //         },
                //         child: SvgPicture.asset("assets/images/Add.svg")),
                //     SizedBox(
                //       height: 10,
                //     ),
                //     GestureDetector(
                //         onTap: () {
                //           Get.to(() => EditEducation());
                //         },
                //         child: SvgPicture.asset("assets/images/edit.svg")),
                //   ],
                // ),
              ],
            ),
            SizedBox(
              height: 20,
            ),
            Visibility(
              visible: isVisible,
              child: ListView.builder(
                physics: NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                itemCount: educationTitle.length,
                itemBuilder: (BuildContext context, index) => Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      educationTitle[index],
                      style: smallStyle.copyWith(
                        fontWeight: FontWeight.w700,
                        color: Color.fromRGBO(21, 11, 61, 1),
                      ),
                    ),
                    SizedBox(
                      height: 6,
                    ),
                    Text(
                      educationSubtitle[index],
                      style: smallStyle.copyWith(
                        fontWeight: FontWeight.w400,
                        color: Color.fromRGBO(82, 75, 107, 1),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

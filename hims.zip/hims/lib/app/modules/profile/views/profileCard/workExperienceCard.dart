import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/route_manager.dart';

import '../../../../constants/styles.dart';
import '../add/addExperience.dart';
import '../edit/editExperience.dart';

class WorkExperienceCard extends StatelessWidget {
  final List<String> workExperienceTitle;
  final List<String> workExperienceSubtitle;
  final bool isVisible;
  final String icon;
  final String title;
  WorkExperienceCard({
    super.key,
    required this.icon,
    required this.title,
    required this.workExperienceTitle,
    required this.workExperienceSubtitle,
    required this.isVisible,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 0.2,
              blurRadius: 0.2,
              offset: const Offset(
                  0, 1), // Changes position of shadow
            ),
          ],
          color: Colors.white),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
        child: Column(
          children: [
            Row(
              children: [
                SvgPicture.asset(icon),
                const SizedBox(
                  width: 16,
                ),
                Text(
                  title,
                  style: smallStyle.copyWith(
                      fontWeight: FontWeight.w700,
                      color: const Color.fromRGBO(21, 11, 61, 1)),
                ),
                const Spacer(),
                SvgPicture.asset("assets/images/Add.svg")
                // Column(
                //   children: [
                //     GestureDetector(
                //         onTap: () {
                //           Get.to(() => AddExperience());
                //         },
                //         child: SvgPicture.asset("assets/images/Add.svg")),
                //     SizedBox(
                //       height: 10,
                //     ),
                //     GestureDetector(
                //         onTap: () {
                //           Get.to(() => EditExperience());
                //         },
                //         child: SvgPicture.asset("assets/images/edit.svg")),
                //   ],
                // ),
              ],
            ),
            const SizedBox(
              height: 20,
            ),
            Visibility(
              visible: isVisible,
              child: ListView.builder(
                physics: const NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                itemCount: workExperienceTitle.length,
                itemBuilder: (BuildContext context, index) => Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      workExperienceTitle[index],
                      style: smallStyle.copyWith(
                        fontWeight: FontWeight.w700,
                        color: const Color.fromRGBO(21, 11, 61, 1),
                      ),
                    ),
                    const SizedBox(
                      height: 6,
                    ),
                    Text(
                      workExperienceSubtitle[index],
                      style: smallStyle.copyWith(
                        fontWeight: FontWeight.w400,
                        color: const Color.fromRGBO(82, 75, 107, 1),
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/route_manager.dart';

import '../../../../constants/styles.dart';
import '../edit/editPersonalInfo.dart';

class PersonalInfoCard extends StatelessWidget {
  final List<String> personalInfoTitle;
  final List<String> personalInfoSubtitle;

  final String icon;
  final String title;
  final int index;
  final bool isVisible;
  PersonalInfoCard({
    super.key,
    required this.icon,
    required this.title,
    required this.personalInfoTitle,
    required this.personalInfoSubtitle,
    required this.index,
    required this.isVisible,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 0.2,
              blurRadius: 0.2,
              offset: const Offset(
                  0, 1), // Changes position of shadow
            ),
          ],
          color: Colors.white),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
        child: Column(
          children: [
            Row(
              children: [
                SvgPicture.asset(icon),
                SizedBox(
                  width: 16,
                ),
                Text(
                  title,
                  style: smallStyle.copyWith(
                      fontWeight: FontWeight.w700,
                      color: Color.fromRGBO(21, 11, 61, 1)),
                ),
                Spacer(),
                SvgPicture.asset("assets/images/Add.svg")
                // GestureDetector(
                //     onTap: () {
                //       Get.to(() => ProfileEditPersonalInfo());
                //     },
                //     child: SvgPicture.asset("assets/images/edit.svg")),
              ],
            ),
            SizedBox(
              height: 20,
            ),
            Visibility(
              visible: isVisible,
              child: ListView.builder(
                physics: NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                itemCount: personalInfoTitle.length,
                itemBuilder: (BuildContext context, index) => Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      personalInfoTitle[index],
                      style: smallStyle.copyWith(
                        fontWeight: FontWeight.w700,
                        color: Color.fromRGBO(21, 11, 61, 1),
                      ),
                    ),
                    SizedBox(
                      height: 6,
                    ),
                    Text(
                      personalInfoSubtitle[index],
                      style: smallStyle.copyWith(
                        fontWeight: FontWeight.w400,
                        color: Color.fromRGBO(82, 75, 107, 1),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

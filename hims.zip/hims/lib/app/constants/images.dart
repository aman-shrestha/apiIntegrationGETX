class AppImages {
  static const appLogo = "assets/images/app.png";
  static const loginBg="assets/images/login_bg.png";
  static const otpVerify="assets/images/otp_verify.svg";
  static const formBg="assets/images/form_bg.png";
}

class AppIcons {
  static const dashedLine="assets/icons/dash_line.svg";
  static const personOutlined="assets/icons/person_outline.svg";
  static const personFilled="assets/icons/person_filled.svg";
  static const experienceOutlined="assets/icons/experience_outline.svg";
  static const experienceFilled="assets/icons/experience_filled.svg";
  static const bedIcon="assets/icons/beds.svg";
  static const icuIcon="assets/icons/icu.svg";
  static const cylinderIcon="assets/icons/cylinder.svg";
  static const ambulanceIcon="assets/icons/ambulance.svg";
  static const generalIcon="assets/icons/generalBlue.svg";
  static const oxygenIcon="assets/icons/oxygenBlue.svg";
  static const ambulanceBlueIcon="assets/icons/ambulanceBlue.svg";
  static const opdWardIcon="assets/icons/OPDBlue.svg";
  static const medicineIcon="assets/icons/medicineBlue.svg";
  static const labIcon="assets/icons/labBlue.svg";
  static const bagIcon="assets/icons/bags.svg";
  static const hospitalIcon="assets/icons/hospital.svg";
  static const locationIcon="assets/icons/location.svg";


}

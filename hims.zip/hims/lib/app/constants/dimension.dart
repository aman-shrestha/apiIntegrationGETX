import 'package:get/get.dart';

class Dimension {
  static double screenHeight = Get.context!.height;
  static double screenWigth = Get.context!.width;

  //my screen height= 783.27
  //my screen width=392.77
  static double hight10 = screenHeight / 78.3;
  static double width10 = screenWigth / 39.7;
}
